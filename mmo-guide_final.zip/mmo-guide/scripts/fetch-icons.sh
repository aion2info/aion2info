#!/usr/bin/env bash
# Lädt die Aion 2 Skill-Icons (Spieldaten, gespiegelt vom aion2pb-CDN) herunter
# und erzeugt 96px-Kopien für den Guide. Icon-Codes werden aus der jeweiligen
# skills.json gelesen (Feld "icon"), damit das Skript für jede Klasse funktioniert.
#
# Aufruf:  bash scripts/fetch-icons.sh <klasse>      z. B. assassin, ranger
#          bash scripts/fetch-icons.sh               (Standard: assassin, Altverhalten)
# Ergebnis: assets/icons/aion2/<klasse>/raw/*.png   (Original 256px)
#           assets/icons/aion2/<klasse>/*.png       (96px, im Guide verwendet)
#
# Quelle der Icons: https://cdn.aion2pb.com/game/UI/Resource/Texture/Skill/<ICON>.png
# Icon-Codes stammen aus der offiziellen Skill-API (siehe docs/research/aion2/sources.md).
#
# Hinweis: Benötigt uneingeschränkten Netzwerkzugriff auf cdn.aion2pb.com. In
# gesandboxten/eingeschränkten Umgebungen (z. B. Cowork-Container) schlägt der
# Download fehl (403) – dann dieses Skript lokal auf einem Rechner mit normalem
# Internetzugang ausführen.
set -u

CLASS="${1:-assassin}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
JSON="$ROOT/data/aion2/$CLASS/skills.json"
OUT="$ROOT/assets/icons/aion2/$CLASS"
RAW="$OUT/raw"
BASE="https://cdn.aion2pb.com/game/UI/Resource/Texture/Skill"

if [ ! -f "$JSON" ]; then
  echo "Keine Datei $JSON gefunden. Aufruf: bash scripts/fetch-icons.sh <klasse>" >&2
  exit 1
fi
mkdir -p "$RAW"

# Icon-Codes (ohne .png) aus skills.json ziehen, doppelte entfernen.
mapfile -t codes < <(node -e '
  const fs = require("fs");
  const data = JSON.parse(fs.readFileSync(process.argv[1], "utf8"));
  const codes = new Set();
  for (const s of data.skills) { if (s.icon) codes.add(s.icon.replace(/\.png$/, "")); }
  console.log([...codes].sort().join("\n"));
' "$JSON")

HAVE_SIPS=0; command -v sips >/dev/null 2>&1 && HAVE_SIPS=1
HAVE_MAGICK=0; command -v convert >/dev/null 2>&1 && HAVE_MAGICK=1

ok=0; missing=0
for c in "${codes[@]}"; do
  [ -z "$c" ] && continue
  f="$RAW/$c.png"
  if [ ! -s "$f" ]; then
    curl -sL --fail -o "$f" "$BASE/$c.png" || rm -f "$f"
  fi
  if [ -s "$f" ] && file "$f" | grep -q "PNG image"; then
    ok=$((ok+1))
    if [ "$HAVE_SIPS" -eq 1 ]; then
      sips -Z 96 "$f" --out "$OUT/$c.png" >/dev/null 2>&1
    elif [ "$HAVE_MAGICK" -eq 1 ]; then
      convert "$f" -resize 96x96 "$OUT/$c.png" >/dev/null 2>&1
    else
      cp "$f" "$OUT/$c.png"
    fi
  else
    rm -f "$f"; missing=$((missing+1))
  fi
done
printf 'Klasse %s – Icons ok: %d, fehlend: %d (Quelle: %s)\n' "$CLASS" "$ok" "$missing" "$JSON"
[ "$HAVE_SIPS" -eq 0 ] && [ "$HAVE_MAGICK" -eq 0 ] && printf 'Hinweis: weder sips (macOS) noch ImageMagick "convert" gefunden – Icons wurden ohne Verkleinerung auf 256px kopiert.\n'
