#!/usr/bin/env bash
# Erzeugt aus data/aion2/<klasse>/skills.json den JS-Wrapper skills.js,
# damit der Guide auch per file:// (ohne lokalen Server) die Daten laden kann.
# Aufruf: bash scripts/sync-data.sh <klasse>      z. B. assassin, ranger
#         bash scripts/sync-data.sh               (Standard: assassin, Altverhalten)
set -eu
CLASS="${1:-assassin}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SRC="$ROOT/data/aion2/$CLASS/skills.json"
OUT="$ROOT/data/aion2/$CLASS/skills.js"
VAR="AION2_$(echo "$CLASS" | tr '[:lower:]' '[:upper:]')"
node -e '
  const fs = require("fs");
  const [src, out, varName] = process.argv.slice(1);
  const data = JSON.parse(fs.readFileSync(src, "utf8"));   // validiert das JSON
  fs.writeFileSync(out,
    "// GENERIERT aus skills.json (bash scripts/sync-data.sh) – nicht von Hand bearbeiten.\n" +
    "window." + varName + " = " + JSON.stringify(data) + ";\n");
  console.log(`${data.skills.length} Skills -> ${out}`);
' "$SRC" "$OUT" "$VAR"
