# Design: Aion 2 Assassin PvE-Guide (Wowhead-Stil)

Stand: 16.09.2026 · Status: umgesetzt unter Annahmen (autonomer Lauf, siehe „Annahmen“)

## Ziel

Ein deutschsprachiger PvE-DPS-Guide für den Assassin in Aion 2, aufgebaut wie die
Wowhead-Klassenguides (Overview / Rotation & Cooldowns / Talents …), mit Fokus auf:

1. **Leveling-Guide mit Skillpunkt-Reihenfolge** – Schritt für Schritt, getrennt nach
   aktiven Skills, passiven Skills und Stigmas, sodass man beim Leveln nur nachschauen
   muss, wohin der nächste Punkt geht.
2. **Freischalt-Reihenfolge** – welcher Skill wann freigeschaltet wird und wie weit
   er wann gelevelt werden soll (eigene Sektion).
3. **Makros & Skill-Anordnung** – Aion 2 erlaubt pro Quickslot eine „Linie“ aus bis zu
   vier Skills (Priorität 0→1→2→3) sowie ein Ingame-Skill-Makro, das Slots in Folge
   abspielt. Der Reiter zeigt eine empfohlene Anordnung, Makro-Inhalte und erklärt kurz
   die Rotation/Opener daraus.
4. **Rotation & Cooldowns** – „So spielt sich der Assassin“, Opener, Prioritätsliste,
   Cooldown-Nutzung, wie bei Wowhead.
5. **Skill-Icons** überall, wo ein Skill genannt wird.
6. Leitmotiv: **maximaler DPS mit so wenig Tasten wie möglich.**

Zusätzlich (Nachricht während der Arbeit): die **Recherche strukturiert im Ordner
ablegen**, damit sie später wiederverwendbar ist (weitere Klassen, Patches, andere Spiele).

## Kontext & Annahmen

- Repo `mmo-guide` war leer (kein Commit). Struktur wird neu angelegt.
- Aion 2 Global erscheint am 05.10.2026 (Early Access 30.09.). Alle Daten stammen aus
  der KR/TW-Version (Skill-API-Stand 15.09.2026) und KR-Community-Guides. Global
  startet laut Vorabinfos mit **4 Stigma-Slots** (Season 1), KR hat 6.
- **Skillnamen auf Englisch** (offizielle Namen des Global-Clients laut Spieldaten).
  Die deutsche Lokalisierung ist bis zum Release nicht öffentlich; deutsche Namen im
  Datensatz sind als „vorläufig“ markiert und später nachzupflegen.
- Guide-Sprache: Deutsch. Community-Kürzel (KR) werden im Glossar erklärt.
- Kein Build-Step: statische HTML/CSS/JS-Seite, per Doppelklick oder lokalem Server
  nutzbar. Skilldaten liegen als JSON (Quelle) und als JS-Wrapper (für `file://`) vor.

## Betrachtete Ansätze

1. **Statische Seite, ein Guide = eine HTML-Datei mit Reitern, Daten aus JSON, Icons lokal**
   – kein Build, sofort nutzbar, Skill-Chips (Icon + Name + Tooltip) werden per JS aus
   den Daten gerendert, Konsistenz garantiert. **Gewählt.**
2. Static-Site-Generator (Astro/Eleventy) mit Markdown-Content – sauberer für viele
   Guides, aber Node-Toolchain und Build-Step für ein einzelnes Guide-Projekt zu viel.
3. Reines Markdown-Dokument – schnell, aber keine Reiter, keine Icons im Fließtext, kein
   Quickbar-Mockup; verfehlt den Wowhead-Anspruch.

## Struktur

```
mmo-guide/
├── README.md                          Einstieg, wie öffnen, wie aktualisieren
├── index.html                         Übersicht aller Guides
├── aion2/assassin/index.html          Der Guide (Reiter: Übersicht · Skills · Leveling ·
│                                      Stigmas · Rotation · Makros & Anordnung · Stats & Gear · Quellen)
├── assets/css/guide.css               Gemeinsames Layout (dunkles Theme, Reiter, Skill-Chips, Quickbar)
├── assets/js/guide.js                 Reiter-Routing (#hash), Skill-Chip-Rendering, Tooltips
├── assets/icons/aion2/assassin/       Skill-Icons 96px (raw/ = 256px Original)
├── data/aion2/assassin/skills.json    Alle Skills: Namen (EN/KR/DE vorläufig), Typ, Level,
│                                      CD, MP, Beschreibung, Spezialisierungen, Ketten, PvE-Rolle,
│                                      empfohlene Spezialisierungen, Ziel-Level, Icon
├── data/aion2/assassin/skills.js      Generierter Wrapper (window.AION2_ASSASSIN) für file://
├── scripts/fetch-icons.sh             Icons laden + verkleinern
├── scripts/sync-data.sh               skills.json → skills.js
└── docs/
    ├── superpowers/specs/…            Dieses Dokument
    └── research/aion2/
        ├── README.md                  Index, Aktualisierungs-Workflow
        ├── sources.md                 Alle Quellen mit Datum, Inhalt, Verlässlichkeit
        ├── systems.md                 Spielsysteme: Mastery/Skillpunkte, Spezialisierung,
        │                              Stigma, Daevanion, Arcana, Slot-Linien, Ingame-Makro,
        │                              Animation-Cancel, Global vs. KR
        ├── assassin-meta.md           KR/TW-Meta: Prioritäten, Builds, Makro-Setups, Patches
        └── glossary.md                EN ↔ KR ↔ DE(vorläufig) + Community-Kürzel
```

## Inhalt des Guides (Reiter)

1. **Übersicht** – Rolle, Stärken/Schwächen, Kernmechaniken (Back Attack, Insignia,
   Heart-Gore-Reset, Stagger, Buff-Fenster), Global-Hinweis, Quick-Build (TL;DR).
2. **Skills & Spezialisierungen** – Spezialisierungssystem erklärt (Slots bei Skill-Lv 8/12/20,
   Optionen 1–3 ab 8, 4 ab 12, 5 ab 16), dann Tabellen: aktive Mastery-Skills, Ketten-
   Skills, passive Skills, Stigmas – je mit Icon, Freischalt-Level, CD/MP, Effekt,
   PvE-Rolle, empfohlener Spezialisierung, Ziel-Level.
3. **Leveling** – (a) Freischalt-Reihenfolge Lv 1–25, (b) Skillpunkte Schritt für Schritt
   als nummerierte Warteschlange (aktiv), (c) passive Warteschlange, (d) Stigma-
   Warteschlange ab Lv 23, (e) Daevanion-Boards, (f) Ziel-Level-Tabelle Leveling/Endgame.
4. **Stigmas** – die 13 Stigmas, PvE-Setup für 4 Slots (+5./6. Slot), Spezialisierungen
   je 5 Stufen, Shard-Kosten, Buff-Synchronisation.
5. **Rotation & Cooldowns** – Kernprinzipien, Opener, Single-Target-Priorität,
   AoE, Cooldowns einzeln, Stagger-Fenster, Positionierung, Fortgeschrittenes.
6. **Makros & Skill-Anordnung** – Slot-Linien erklärt, empfohlene Quickbar (Mockup mit
   Icons), Ingame-Makro (Aufbau, Delay, Skill-Queue), Ein-Tasten-Filler + Burst-Taste,
   was manuell bleibt, Test-Protokoll, Hinweis zu externen Makros.
7. **Stats & Gear** – kompakt: Stat-Prio, Accuracy-Check, Manasteine, Arcana-Reihenfolge.
8. **Quellen & Stand** – Datenstand, Patch-Baseline, Global-Vorbehalte, Quellenliste.

## Datenmodell `skills.json`

```json
{
  "meta": { "game": "Aion 2", "class": "Assassin", "data_date": "2026-09-15", "sources": [] },
  "skills": [{
    "id": "heart-gore", "api_id": 13350000,
    "name": { "en": "Heart Gore", "kr": "심장 찌르기", "de_provisional": "Herzstoß" },
    "aliases_kr": ["심찌"],
    "type": "active|chain|passive|stigma|system",
    "unlock_level": 4, "cooldown": "5s", "mp": null, "range": "4m",
    "description": "…", "chain": { "from": null, "to": null },
    "specs": [{ "slot_unlock": 8, "text": "…" }],
    "pve": { "role": "core|burst|utility|movement|defense|situational|skip",
             "priority": 1, "target_level_leveling": 8, "target_level_endgame": 20,
             "recommended_specs": [2,4,5], "notes": "…" },
    "icon": "ICON_AS_SKILL_035.png"
  }]
}
```

## Fehlerbehandlung / Grenzen

- Fehlt ein Icon, rendert der Chip einen Platzhalter mit Kürzel.
- `file://`: Daten kommen aus `skills.js`; bei Server-Betrieb identisch.
- Unsichere Daten (Global-Slots, Skillpunkt-Kosten pro Stufe) sind im Guide als solche
  markiert; die Warteschlangen sind bewusst punktkosten-unabhängig formuliert.

## Test

- Seite im Browser öffnen: alle Reiter erreichbar, Hash-Links funktionieren, alle
  Skill-Chips zeigen Icon + Name, Tooltips öffnen, Mobile-Breite ohne horizontales Scrollen.
- Daten-Check: jede Skill-ID im HTML existiert in `skills.json` (Konsolen-Warnung sonst).
