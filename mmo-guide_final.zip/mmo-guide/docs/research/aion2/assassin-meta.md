# Assassin PvE – KR/TW-Meta (Stand 16.09.2026)

Konsolidiert aus Field Manual (Aug 2026), Vortex-Übersetzungen (Nov 2025–Sept 2026),
Inven-Guides und -Builds (Jan–Juli 2026), gegebase (Sept 2026). Skillnamen englisch.

## 1. Kern-Skills und Ziel-Level

| Skill | Ziel-Level (Endgame) | Warum |
|---|---|---|
| Heart Gore | 20 | Spez. 5 (Lv 16): Reset bei Krit → Dauerschleife; Hauptschaden |
| Insignia Explosion | 20 (mind. 16) | Burst, skaliert mit Insignia-Stapeln; Spez. 5: −3 s CD |
| Quick Slice | 20 | Füller ohne CD, MP-Rückgewinn, Spez. 4 senkt Insignia-Explosion-CD, Spez. 5 garantiert Krit |
| Savage Roar | 20 (mind. 12) | Insignia-Aufbau, +12 % Einzelziel, Spez. 4 senkt Shadowstrike-CD |
| Ambush | 16 → 20 | +30 % von hinten; Spez. 5 (Lv 16): +2 Nutzungen |
| Storm Rampage | 16 (optional 20) | Nur im Stagger-Fenster; Spez. 5: −1 s alle CDs pro Treffer |
| Shadowstrike | 8 → 12/16 | Gap-Closer hinter das Ziel; Spez. 2: +20 % Crit-Damage-Boost 10 s |
| Shadow Fall | 12 | Nach Betäubung; Spez. 1 Heal / 2 drei Insignia / 3 −5 s CD |
| Whirlwind Slice | 12 (16 für AoE) | 10-s-Füller mit Stun-Chance; Spez. 5: Reset-Chance |
| Flash Slice | 8 → 12 | Repositionierung + Blind; Spez. 2 Reichweite, 4 +1 Nutzung |
| Infiltrate | 8 → 12 | Nach Dodge hinter das Ziel; Spez. 1 Ausdauer, 2 Reichweite |
| Defiance | 8 → 12 | Entstörer; Spez. 3: 20 % HP |

Vortex 1009935 (Sept 2026): „Level-20-Priorität: Heart Gore, Insignia Explosion, Quick
Slice, Savage Roar.“ Inven-Build (Jan 2026): Quick Slice 20, Ambush 20, Heart Gore 20,
Storm Rampage 16, Whirlwind Slice 16, Insignia Explosion 16, Savage Roar 14, Flash Slice 12,
Infiltrate 12, Shadow Fall 12, Shadowstrike 8, Defiance 8 (Budget 396 Mastery-Punkte).
Arcana-Reihenfolge (Field Manual): Heart Gore 20 > Insignia Explosion 20 > Quick Slice 20 >
Savage Roar 20 > Storm Rampage 16 > Ambush 16.

## 2. Spezialisierungs-Picks (Option-Nummern nach Skill-API)

Slots: 1 bei Skill-Lv 8, 2 bei 12, 3 bei 20. Option 5 wird bei Lv 16 verfügbar und ersetzt
dann meist die schwächste belegte Option.

| Skill | Optionen (1–5) | Lv 8 | Lv 12 | Lv 16 | Lv 20 | Quellen |
|---|---|---|---|---|---|---|
| Quick Slice | 1 +20 % MP · 2 HP-Absorb · 3 +50 % Multi-Hit · 4 −1 s Insignia-Explosion-CD/Treffer · 5 ignoriert Block/Ausweichen, Krit | 3 | 3,4 | 3,5 | 3,4,5 (Solo: 2,4,5) | Vortex 854915, Field Manual |
| Heart Gore | 1 HP-Absorb · 2 1 Insignia · 3 bis +20 % Krit bei wenigen Zielen · 4 Multi-Hit · 5 CD-Reset bei Krit | 3 (Solo 1) | 3,4 | 4,5 | 3,4,5 (Progression 1,4,5) | Vortex 854915, Field Manual |
| Insignia Explosion | 1 Rotieren · 2 +50 % Multi-Hit · 3 2 Stapel bleiben · 4 +1 s Stun · 5 −3 s CD | 2 | 2,3 | 2,5 | 2,3,5 | Vortex 854915, Field Manual |
| Savage Roar | 1 −20 % MP · 2 +20 % Skill-Speed · 3 bis +12 % Schaden bei wenigen Zielen · 4 −1 s Shadowstrike-CD/Treffer · 5 Pull bei Savage Smash | 3 | 2,3 | 2,3 | 2,3,4 | Vortex 854915, Field Manual |
| Ambush | 1 2 Insignia bei Rückenangriff · 2 3 % HP-Absorb · 3 Schilde brechen · 4 50 % Whirlwind Slice auslösen · 5 +2 Nutzungen | 1 (Solo 2) | 1,4 | 1,5 | 1,4,5 (Solo 2,4,5) | Vortex 854915 |
| Shadowstrike | 1 +1 s Stun · 2 +20 % Crit-Dmg-Boost 10 s · 3 Seal · 4 Root · 5 AoE | 2 | 2 | 2,5 | 2,5 | Vortex 854915 („Stealth Attack“) |
| Storm Rampage | 1 5 % HP-Absorb · 2 +120 MP · 3 mobil · 4 Multi-Hit · 5 −1 s alle CDs/Treffer | 1 | 1,4 | 4,5 | 1,4,5 | Field Manual, Vortex |
| Whirlwind Slice | 1 +50 % Multi-Hit · 2 AoE · 3 +16 m Reichweite · 4 +20 % Stun · 5 25 % Reset bei Ausweichen | 1 | 1,2 (Farm) / 1,3 | – | 1,2/3,5 | Vortex 854915 |
| Flash Slice | 1 +2 s Blind · 2 +6 m Reichweite · 3 mehr Schaden bei mehr Zielen · 4 +1 Nutzung · 5 Stun bei geblendetem Ziel | 2 | 2,4 | – | – | Vortex, Field Manual |
| Infiltrate | 1 +300 Ausdauer · 2 +10 m Reichweite · 3 Schilde brechen · 4 Dark-Strike-Kette · 5 +20 % Blind | 2 | 1,2 | – | – | Vortex, Field Manual |
| Shadow Fall | 1 10 % HP-Absorb · 2 3 Insignia · 3 −5 s CD · 4 +1 s Knockdown · 5 nutzbar bei Blind | 1 (DPS 2) | 1,3 | – | – | Vortex, Field Manual |
| Defiance | 1 Storm-Slice-Kette · 2 +1000 Ausdauer · 3 20 % HP · 4 +2 s Tenacity · 5 +50 % PvE-Dmg-Tolerance | 3 | 2,3 | 3,5 (Progression) | – | Vortex, Field Manual |

## 3. Passive Skills

Reihenfolge (Field Manual, Vortex): **Rear Smite** (S) > **Assault Stance** (S) > **Exploit
Weakness** (S, +Krit, Attack-Proc, Klone mit Insignia) > **Impact Hit** (A) > Heightened
Sixth Sense / Revitalization Contract (B, nach Bedarf) > Ambush Stance, Defense Break,
Determination, Apply Poison (Rest). Endgame-Beispielwerte mit Gear/Arcana: Rear Smite ~36,
Assault Stance ~34, Exploit Weakness ~29, Impact Hit ~25.

## 4. Stigma

Reihenfolge: **Illusive Clone** → **Swift Contract** → **Triniel's Dagger** → **Savage Fang**;
Slot 5: **Evasion Stance** (Defensive) oder **Throw Shadowblade** (Reichweite/Farm); Slot 6:
das jeweils andere.

| Stigma | Kernnutzen | Level-Ziel |
|---|---|---|
| Illusive Clone (90 s) | Setzt Heart-Gore-CD zurück, +20 % Zusatzschaden 10 s; Lv 10 +20 % Crit-Dmg, Lv 15 ×1,5 Exploit Weakness, Lv 25 −1 s CD pro kritischem Rückenangriff | 10 → 20 → 25 |
| Swift Contract (60 s) | +20 % Combat Speed 10 s; Lv 10 ×1,5 Rear Smite, Lv 15 ×1,5 Assault Stance, Lv 20 +10 % Speed, Lv 25 +10 % Attack | 10 → 20 → 25 |
| Triniel's Dagger (45 s) | Großer Schlag (+30 % von hinten), **Lv 10: −10 % alle eigenen CDs bei Treffer**, Lv 20 +3 %, Lv 25 +10 % Back-Attack-Boost | 10 → 20 → 25 |
| Savage Fang (60 s) | 5 Insignia sofort, 50 Stagger-Schaden (+50 bei Lv 10), Lv 15 +10 % PvE-Schaden 10 s, Lv 20 garantierter Krit | 10 → 20 |
| Evasion Stance (20 s) | Garantiertes Ausweichen, MP/Ausdauer; Lv 5 +1 Nutzung | 5 (→ 20 für Progression) |
| Throw Shadowblade (30 s) | Fernangriff + Slow; Lv 5 Kette, Lv 20 AoE | 10 → 20 (Farm) |

Buff-Zyklus: Clone + Swift + Fang stapeln → Triniel's Dagger (Schaden + CD-Effekt) → Kern-
Skills von hinten; kritische Rückenangriffe ziehen den Clone-CD vor. Getestete Richtwerte
(Field Manual): 80 % Rücken-Uptime, ≥35 % CDR komfortabel; Community-Ziele 83 % Combat
Speed + 32 % CDR (mit Scroll), mit Kantor-Buff 88 % / 56 %. CDR wirkt multiplikativ.

## 5. Rotation (Prioritätensystem, kein fester Ablauf)

1. **Rückenposition sichern** (Shadowstrike, Infiltrate nach Dodge, Flash Slice); einen
   Bewegungsskill für Boss-Drehungen zurückhalten.
2. **Buff-Fenster**: Illusive Clone + Swift Contract + Savage Fang → Triniel's Dagger; darin
   Heart Gore (nach jedem Krit), Insignia Explosion (bei 4–5 Stapeln), Quick Slice, Savage Roar.
3. **Stagger-Fenster**: Storm Rampage, wenn kein Burst offen ist; nicht reflexartig.
4. **Defensive** vor Downtime: Evasion Stance, Defiance (20 % HP), Shadow Fall (Heal-Spez.).
5. **Cooldowns nur kurz verzögern** (3–8 s) für Buff-Ausrichtung; Triniel's Dagger nie unbegrenzt halten.

Häufige Fehler (Field Manual, gegebase): von vorne angreifen; Ketten abbrechen; Insignia
Explosion als Füller statt auf Stapel; Clone/Swift auseinanderdriften lassen; Defensive zu
früh entfernen; Accuracy-Fehlschläge ignorieren.

Frühe Kombos (Vortex 601044/606019): Flash Slice (Blind) → Rechtsklick-Angriffe (Savage
Roar, Insignia aufbauen) → Insignia Explosion (Stun) → Shadow Fall. Basiskombo mit
Normalangriff-Cancel: Ambush → LMB → Shadowstrike → LMB → Heart Gore → LMB → Insignia
Explosion. Inven-Build-Notiz: „1, 2 drücken → links/rechts wechseln bis Heart-Gore-CD → links/2 wechseln“.

## 6. Quickbar-Layouts und Makros aus KR-Guides

**Inven 6449/3726 (5.3 PvE):**

| Taste | Linie (Priorität 0 → 3) |
|---|---|
| LMB | Quick Slice (Kette) |
| RMB | Whirlwind Slice → Insignia Explosion → Heart Gore → Ambush |
| E | Shadowstrike → Infiltrate → Flash Slice |
| R | Storm Rampage |
| Q | Triniel's Dagger |
| 1 | Illusive Clone |
| 2 | Swift Contract |
| 3 | Throw Shadowblade |

Ingame-Makro: LMB-Slot 50 ms → LMB-Slot 50 ms → Savage-Roar-Slot 80 ms (Skill-Queue AN).
Boss-Opener: Illusive Clone + Swift Contract + Shadowstrike → Triniel's Dagger von hinten →
LMB/RMB im Wechsel, Rücken halten, Skills in den CD-Fenstern nachlegen.

**Field Manual / SoundFox (Juli 2026):** Ingame-Makro mit **einem** Eintrag (Slot „Insignia
Explosion“, 10 ms), extern im Wechsel mit Normalangriff; manuell bleiben Savage Roar,
Illusive Clone, Swift Contract, Triniel's Dagger, Bewegung, Defensive, Storm Rampage.

**Vortex 1009935 (Sept 2026):** RMB-Linie: Insignia Explosion, Heart Gore, Savage Roar;
Quick Slice auf eigener Taste; Wechsel Quick Slice/Makro alle 10 ms (extern); Presets:
PvE-Preset auf `~`, CDR-Preset auf F9.

**Inven 6449/3875:** Delay-Werte bei 70 % Kampfgeschwindigkeit: Normalangriff 100,
starker Angriff 530 (Zehntel-ms-Skala des externen Tools); Standard 50 verschluckt Eingaben.

## 7. Stats & Gear (kompakt)

- Reihenfolge: Krit (Genus-Ziel ~2 200) → Accuracy bis keine Fehlschläge → Attack /
  Weapon Damage Boost / Back Attack Damage Boost / Critical Damage Boost → Combat Speed →
  Defensive nur für Progression.
- Manasteine (Endgame): Back Attack Damage Boost > Weapon Damage Boost > Critical Damage
  Boost > Attack +30/+25 > Damage Boost.
- Schadensformel (Inven-Tests): (1 + Damage + PvE + Boss + Race) × (1 + Rear Boost);
  Rear-Boost ist der einzige separate Multiplikator.
- Ausrüstungseffekte: Waffen Combat Speed; Helm/Umhang Smite + Attack; Ringe aktive
  Skill-Level (Heart Gore > Insignia Explosion > Quick Slice > Storm Rampage);
  Rüstungsteile passive Skill-Level (Rear Smite = Assault Stance > Impact Hit > Exploit Weakness).
- Titel/Flügel/Pantheon: Stat „Illusion“ (Pantheon) und Flügel mit CDR für den CDR-Build.

## 8. Global-Vorbehalt

Alle Zahlen sind KR/TW-Stand. Für Global: 4 Stigma-Slots (Illusive Clone, Swift Contract,
Triniel's Dagger, Savage Fang), Stigma-Level 20 als Ziel, Arcana ggf. reduziert. Prioritäten
gelten unverändert; Werte im Client prüfen.
