# Recherche: Aion 2 (Assassin, Ranger & Gladiator, PvE)

Wissensbasis für die Guides unter `aion2/assassin/`, `aion2/ranger/` und `aion2/gladiator/`.
Alles, was hier liegt, ist so geschrieben, dass es ohne den Chatverlauf verständlich und für
weitere Klassen, Patches oder Spiele wiederverwendbar ist.

| Datei | Inhalt |
|---|---|
| [sources.md](sources.md) | Alle Quellen mit URL, Datum, entnommenen Informationen und Verlässlichkeit (Assassin, Ranger und Gladiator) |
| [systems.md](systems.md) | Spielsysteme: Mastery-Skills & Skillpunkte, Spezialisierung, Stigma, Daevanion, Arcana, Quickslot-Linien, Ingame-Skill-Makro, Animation-Cancel, Global vs. KR, Patch-Historie (klassenübergreifend) |
| [assassin-meta.md](assassin-meta.md) | KR/TW-Meta für den Assassin: Kern-Skills, Spezialisierungs-Picks, Passiv- und Stigma-Prioritäten, Buff-Zyklus, Rotation, Quickbar-Layouts und Makros aus KR-Guides |
| [ranger-meta.md](ranger-meta.md) | KR-Meta für den Ranger: Namensabgleich KR↔EN, Kern-Skills, Stigma-Prioritäten (zwei Momentaufnahmen), Rotation/Makro-Widerspruch, Stats, offene Punkte |
| [gladiator-meta.md](gladiator-meta.md) | Meta für den Gladiator: Rollen-Einordnung (Bruiser/Off-Tank statt Haupttank), Kern-Skills, Knockdown-/Stagger-Ketten, Stigma-Set, Stats, offene Punkte |
| [glossary.md](glossary.md) | Skillnamen EN ↔ KR ↔ DE (vorläufig), Community-Kürzel, Spielbegriffe |
| `../../../data/aion2/assassin/skills.json` | Maschinenlesbare Skilldaten Assassin (Quelle der Wahrheit für den Guide) |
| `../../../data/aion2/ranger/skills.json` | Maschinenlesbare Skilldaten Ranger (gleiches Schema; siehe `meta.notes` im File für Einschränkungen) |
| `../../../data/aion2/gladiator/skills.json` | Maschinenlesbare Skilldaten Gladiator (gleiches Schema; Freischalt-Level bestätigt, siehe `meta.notes` im File) |

## Datenstand

- Assassin-Skilldaten: offizielle NCSOFT-Skill-API (KR/TW-Client) mit vollständigen
  Tooltip-Texten, Stand **15.09.2026**, via aion2.app.
- Ranger-Skilldaten: vollständige Tooltip-Texte, Cooldowns, Reichweiten und
  Spezialisierungs-Effekte über die offizielle questlog.gg-tRPC-API, Stand **18.09.2026**
  (korrigierte Fassung – die ursprüngliche Version enthielt einen fabrizierten Skill, siehe
  `ranger-meta.md` und `sources.md`). Charakter-Freischalt-Level weiterhin unbestätigt
  (`unlock_level_confirmed: false`).
- Gladiator-Skilldaten: vollständige Tooltip-Texte, Cooldowns, Reichweiten und
  Spezialisierungs-Effekte über dieselbe questlog.gg-API, Stand **18.09.2026**.
  Charakter-Freischalt-Level zusätzlich über `aion2.app` bestätigt und 1:1 mit den
  questlog.gg-Namen abgeglichen (`unlock_level_confirmed: true`) – als einziger der drei
  Datensätze mit vollständig bestätigtem Freischalt-Level.
- Meta/Prioritäten: KR/TW-Guides und internationale Community-Quellen Juli–September 2026
  (Chapter 1, Level 50, Lv-25-Stigmas).
- Aion 2 **Global**: Early Access 30.09.2026, Release 05.10.2026. Global startet mit
  4 Stigma-Slots (Season 1) und älterem Balance-Stand. Werte vor Verwendung im Client prüfen.

## Konventionen

- Kanonische Skillnamen: **Englisch** (Namen aus den Spieldaten). Deutsche Namen sind
  eigene Arbeitsübersetzungen und in Daten/Doku als `de_provisional` markiert.
- Skill-IDs: kebab-case des englischen Namens (`heart-gore`, `insignia-explosion`, `sword-aura-rampage`).
- Icons: `assets/icons/aion2/<klasse>/<ICON_CODE>.png`, Codes aus der questlog.gg-API bzw. -Übersicht.
- Unsicheres ist im Text als „unbestätigt“ oder „abgeleitet“ markiert.

## Aktualisieren

1. Skilldaten prüfen: offizielle questlog.gg-tRPC-API (`database.getSkills`/`getSkill`,
   `mainCategory` = `assassin`/`ranger`/`gladiator`) für Tooltip-Texte, Cooldowns,
   Spezialisierungen; `https://aion2.app/db/skills?class=<Assassin|Ranger|Gladiator>` für
   Freischalt-Level.
2. Änderungen in `data/aion2/<klasse>/skills.json` nachziehen, danach
   `bash scripts/sync-data.sh <klasse>`.
3. Neue Icons: über `cdn.questlog.gg/aion-2/assets/Game/UI/Resource/Texture/Skill/<ICON_CODE>.webp`
   (per Browser-Pane, da direkter Netzwerkzugriff aus Sandbox-Umgebungen teils blockiert ist)
   oder `bash scripts/fetch-icons.sh <klasse>` auf einem Rechner mit Zugriff auf `cdn.aion2pb.com`.
4. Patch-Historie in `systems.md` ergänzen, Quellen in `sources.md` eintragen.
5. Meta-Änderungen (Prioritäten, Makros) in `assassin-meta.md`, `ranger-meta.md` bzw.
   `gladiator-meta.md`, dann im jeweiligen Guide anpassen.
