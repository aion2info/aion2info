# Aion 2 – Sorcerer (마도성), Recherche-Notizen (Stand 19.09.2026)

## 0. Wichtigster Unterschied zu assassin-meta.md / ranger-meta.md / gladiator-meta.md

**Status 19.09.2026 – gelöst:** Für Assassin, Ranger und Gladiator lag die offizielle
Skill-API bereits vor (questlog.gg bzw. aion2.app, per Browser-Pane abgerufen: WebFetch
scheitert an beiden Seiten, da sie clientseitig gerendert werden – siehe `sources.md`).
Für den Sorcerer war in einer früheren Session **kein Browser-Zugriff verfügbar**
(`mcp__claude-in-chrome__*`-Tools meldeten „Browser extension is not connected“,
Rechner/Erweiterung nicht erreichbar); der Guide beruhte deshalb zunächst ausschließlich
auf KR-Community-Threads (Inven, Vortex Gaming) und deren automatisierter Übersetzung.
Dieser Zugriffs-Engpass ist inzwischen behoben: Am 19.09.2026 wurde über den eingebauten
Browser-Bereich (built-in browser pane) Zugriff auf `https://questlog.gg/aion-2/en/db/skills/sorcerer`
hergestellt und alle 35 echten Sorcerer-Skills (12 aktiv, 13 Stigma, 10 passiv) per
tRPC-API (`database.getSkill`/`getSkills`) abgerufen. `data/aion2/sorcerer/skills.json`
liegt jetzt nach demselben Schema wie Ranger/Gladiator vor, ebenso die Icons unter
`assets/icons/aion2/sorcerer/` und der überarbeitete Guide `aion2/sorcerer/index.html`
mit dem gleichen Skill-Chip-/Tooltip-System wie die anderen drei Klassen. Die
KR-Community-Erkenntnisse in diesem Dokument (Abschnitte 3–7) bleiben als Meta-/
Prioritäts-Kontext gültig, sind aber inzwischen auf die tatsächlichen API-Skillnamen
abzubilden statt auf die vorherigen Community-Übersetzungen (siehe Abschnitt 4).

## 1. Klassenname und Rolle

- KR: 마도성 (wörtlich etwa „Magiestern"). Quelle: vgamelifev.com-Klassenübersicht (Verl. B).
- Rolle laut aion2kina.com (offizielle Rollenbeschreibung, Verl. C): „a ranged role
  focused on high magic damage in a short window, with range and control management
  required." Waffe: Spellbook (Zauberbuch).
- Rolle laut aion2boost.com (Verl. C): „ranged burst, the roster's premier area damage,
  and crowd control that shapes fights before damage decides them." Größte Schwäche:
  Fragilität; „widest source disagreement" über die tatsächliche PvE-Gesamtstärke.
- Zwei Elemente: Feuer (Flächen-/Dauerschaden) und Eis (Kontrolle/Selbstschutz durch
  Abstand). Combo-Prinzip laut u4gm.com (Verl. C): Einfrieren → gefrorenes Ziel für
  Bonusschaden „zerschlagen" → mit Feuer-Dot nachlegen.

## 2. Skill-Roster (ungeprüft, Aggregator-Quelle)

aion2hub.com/classes/sorcerer (Verl. C, keine Unlock-Level/CDs) nennt 37 aktive und
10 passive Skills als Namensliste. Diese Liste wurde für den Guide **nicht 1:1
übernommen**, weil sie (wie beim Ranger vor der questlog.gg-Korrektur) unverifiziert
ist und mit den KR-Quellen an mehreren Stellen abweichende Namen für vermutlich
dieselben Skills verwendet (siehe Abschnitt 4). Nur die im Guide selbst verwendeten,
mehrfach belegten Kern-Skills gelten als einigermaßen gesichert.

## 3. Kern-Skills und Prioritäten (Quellenlage)

| Skill (Guide-Name) | KR | Funktion | Quelle(n) |
|---|---|---|---|
| Flame Arrow | 불꽃화살 | Linksklick-Filler, Multi-Hit, setzt Feuermarkierung | inven 6453/66, inven 6453/3334 |
| Flame Burst | 지연폭발 | Verzögerter Schaden, Lifesteal-Option, Reset durch Ice Shard | inven 6453/66, vortexgaming 675679 |
| Flame Spear | 화염창 | Einzelzielschaden, castbar im Laufen | inven 6453/3334, vortexgaming 675679 |
| Hellfire | 지옥의화염 | Flammenzone, Multi-Hit, Opener | inven 6453/66, inven 6453/13273 |
| Flame Barrage | 화염연타 | Multi-Hit, CD-Interaktion | inven 6453/66, vortexgaming 675679 |
| Flame Explosion | 화염폭발 | Fläche, Slow, Lifesteal | vortexgaming 675679, aion2hub-Rosterliste (als „Firestorm"?) |
| Frigid Wind | 혹한의바람 | Fesselung/Schaden, Widerstandsreduktion | inven 6453/66 („Frigid Wind"), vortexgaming/aion2kina-Kontext („Ice Chain") |
| Winter's Shackle | 겨울의족쇄 | CC, Widerstandsreduktion, ~15 s | inven 6453/3334 |
| Ice Shard / Frozen Shard | – | Reset für Flame Burst | inven 6453/66 |
| Wish of Concentration (Community: „Concentrated Origin") | 집중의기원 | Buff: CD-Reduktion + Kampftempo | inven 6453/66, inven 6453/13273 |

Alle Zuordnungen Verl. B (KR-Community), aber **nicht querverifiziert gegen die
Spieldaten selbst** – anders als bei Assassin/Ranger/Gladiator.

## 4. Bekannte Namensabweichungen zwischen Quellen

- 혹한의바람: „Frigid Wind" (inven 6453/66) vs. „Ice Chain" (Kontext vortexgaming/aion2kina)
  vs. „Bitter of the Wind" (aoeah.com, Verl. D).
- 지연폭발: „Delayed Explosion" (wörtlich) vs. Bestandteil von „Flame Burst" in anderer
  Quelle – möglicherweise derselbe Skill mit Stigma-Variante.
- 집중의기원: „Concentrated Origin" (inven) vs. „Wish of Concentration" (aion2hub-Roster,
  jetzt durch die questlog.gg-API bestätigt – das ist der kanonische Name).
- 화염창: „Flame Spear" (inven/vortexgaming) vs. „Flame Harpoon" (aoeah.com).

Der Guide verwendet durchgehend die Inven-/Vortex-Übersetzung, weil beide Quellen
unabhängig zu denselben Prioritäten kommen (Indiz für dieselbe Mechanik trotz
unterschiedlicher Übersetzung). aoeah.com wurde als Verl. D eingestuft und nur als
Gegenprobe verwendet, nicht als Namensquelle.

## 5. Stigmas

Priorität laut vortexgaming.io/postdetail/675679 und inven 6453/3334 (beide Verl. B,
kommen unabhängig zu ähnlicher Reihenfolge):

1. Elemental Reinforcement (원소강화) – Schadensbuff. Laut gamerstogether.cz (Verl. C,
   zitiert KR-Patch 08.07.2026) von 10 % auf 20 % verdoppelt – **nicht für Global
   bestätigt**.
2. Flame Barrier (화염방벽)
3. Delayed Explosion / Flame Burst (Stigma-Variante, 지연폭발)
4. Steel Shield/Barrier (강철방벽) – einziges nennenswertes Defensiv-Stigma
5. Hibernation – neuer Stigma-Skill, eingeführt mit dem klassenweiten Stigma-Rework
   vom 25.03.2026 (aion2hub.com/updates/aion-2-update-2026-03-25, Verl. B: Stigma-Slots
   auf 5 erhöht, ein neuer Stigma-Skill je Klasse). PvE-Einordnung von Hibernation in
   den ausgewerteten Quellen nicht eindeutig belegt.

Inven 6453/3334 unterscheidet zusätzlich einen Einsteigerpfad (Elemental
Reinforcement 5 → Delayed Explosion 10 → Elemental Reinforcement 15 → Flame Barrier 20
→ Steel Shield 5–10) von der finalen Priorität oben – im Guide übernommen.

## 6. Stats

Zwei unterschiedliche Statprioritäten je nach Quelle/Kontext:

- **Frühe/Leveling-Priorität** (u4n.com aion-2-sorcerer-build-guide-2026, Verl. C):
  Magic Attack → Cast Speed → Critical Chance → MP-Regeneration → HP/Defense.
- **Endgame-Priorität** (inven 6453/66, Verl. B): Weisheit (Precision-Äquivalent, erhöht
  Krit-Chance) und kritischer Schaden als Kernstat, Ziel „mindestens Verdopplung" beim
  kritischen Schaden. Accuracy und Krit werden in mehreren Quellen über reinen
  Angriffswert gestellt, sobald genug Grundschaden vorhanden ist.
- Ausrüstungsempfehlung „Waffe mit Genauigkeit + kritischer Trefferchance" nur durch
  eine einzelne Quelle belegt (aoeah.com, Verl. D – als „White Dragon Lord Tome"
  benannt, nicht weiter geprüft).

## 7. Makro/Rotation

Inven 6453/13273 (Ingame-Makro-Thread, Verl. B) beschreibt eine Tastenaufteilung
(Linksklick = Ingame-Makro/Grundrotation, Rechtsklick = Opener-/Burst-Skills manuell,
Seitentaste = Flächenskills nach Cooldown-Verfügbarkeit) mit Referenz-Ausrüstungsstand
(~655.000 Angriffskraft, 160 Mio. DPS, 800 Kampftempo-Basis) – **nicht auf Global
Season 1 übertragbar**, nur als Strukturbeispiel verwendet. Keine expliziten
Delay-Werte (ms) in dieser Quelle; allgemeine Makro-Prinzipien aus dem
Assassin-Guide (`systems.md`, Abschnitt 8) gelten klassenübergreifend.

## Status (19.09.2026)

Die API-Daten sind abgerufen und eingebaut: `data/aion2/sorcerer/skills.json` (35 echte
Skills, Schema wie Ranger/Gladiator), Icons unter `assets/icons/aion2/sorcerer/`, Guide
`aion2/sorcerer/index.html` komplett auf das Skill-Chip-/Tooltip-System umgestellt. Die
in Abschnitt 4 gelisteten Namensabweichungen sind damit aufgelöst (kanonisch: die
englischen API-Namen, siehe `skills.json`). Offen bleibt weiterhin nur das
Charakter-Freischalt-Level je Skill (`unlock_level`, von der API nicht geliefert,
`unlock_level_confirmed: false`) sowie der Abgleich der Stigma-Slot-Zahl (5 laut
KR-Patch 25.03.2026 vs. 4 Slots in Global Season 1 laut `systems.md`) – beides im
Client gegenprüfen, sobald er läuft.
