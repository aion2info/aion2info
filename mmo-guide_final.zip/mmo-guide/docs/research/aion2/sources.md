# Quellen (abgerufen am 16.09.2026)

Verlässlichkeit: **A** = Spieldaten/offiziell · **B** = etablierte KR/TW-Community (Inven, Vortex-Übersetzungen, spezialisierte Fan-Sites) · **C** = westliche Aggregator-Seiten (teils ungenau, Namen abweichend) · **D** = nur als Hinweis, widersprüchlich

## Spieldaten & Datenbanken

| Quelle | Typ | Entnommen | Verl. |
|---|---|---|---|
| https://aion2.app/db/skills?class=Assassin und `/db/skills/<id>` | Skill-DB aus der offiziellen NCSOFT-API, Stand 15.09.2026 | Alle 50 Assassin-Skills: Namen, Freischalt-Level, CD, MP, Reichweite, Beschreibung, alle 5 Spezialisierungen inkl. Freischalt-Skill-Level, Ketten (1/3 → 2/3 → 3/3), Stigma-Spezialitäten bei Lv 5/10/15/20/25, Icon-Codes | A |
| https://aion2pb.com/articles/Assassin | Datenbank (Aion 2 PowerBook) | Kurzbeschreibungen, Icon-CDN `https://cdn.aion2pb.com/game/UI/Resource/Texture/Skill/<ICON>.png` (256 px PNG) | A |
| https://aion2hub.com/classes/assassin | Datenbank/Klassenseite | Offizielle englische Skillliste (37 aktive, 9 passive), Rollenbeschreibung | A/B |
| https://aion2hub.com/leveling/elyos-levels-10-25 | Leveling-Guide (07.06.2026) | Daevanion ab Lv 12, Stigmas ab **Lv 23**, bis zu 4 gleichzeitig; Verstecke (Hideouts) Lv 15/20/25 | B |
| https://aion2.inven.co.kr/db/skillsimulator/193 | KR Skill-Simulator (Build vom 03.01.2026) | Budget „Mastery-Punkte 396 / Stigma-Shards 130“; reales PvE-Build mit Skill-Leveln je Slot; KR-Skillnamen; Quick Slice: Recast 1 s, Spezialisierungswerte skalieren mit Level (0,7 % → 1,5 % HP-Absorb) | B |

## KR-Community (Inven, Übersetzungen)

| Quelle | Entnommen | Verl. |
|---|---|---|
| https://www.inven.co.kr/board/aion2/6444/1899 – „스킬 매크로 설정법 (슬롯, 라인 개념)“ | Ingame-Makro referenziert **Slots**, nicht Skills; jeder Slot hat eine „Linie“ mit Priorität 0→1→2→3; das Makro nutzt alle Skills der Linie nach Priorität; Angriffe und Buffs in getrennte Linien legen | B |
| https://www.inven.co.kr/board/aion2/6444/129 – Dev-Stream #5 | Quickslot-Registrierung, Ketten pro Slot 0→1→2→3, Spezialisierung durch Skill-Level, Stigma-Optionen automatisch | B |
| https://www.inven.co.kr/board/aion2/6444/2034 – „스킬 포인트 배분 (423p)“ | 423 Skillpunkte gesamt (Lv 1–50 + Steine der Weisheit aus Shugo Festa/Nightmare Stufe 4 + Chapter-1-Einmalinhalte); reicht für 11 aktive + 9 passive Skills auf Max, ein Skill (Groggy-Skill) bleibt auf 1 | B |
| https://www.inven.co.kr/board/aion2/6444/1723 – Stigma-Shard-Tabelle | Shards kumuliert: 0→5: 5 · 0→10: 15 · 0→15: 35 · 0→20: 75 (AP: 100k / 375k / 875k / 1,875 Mio) | B |
| https://www.inven.co.kr/board/aion2/6449/3726 – „5.3 살성 PVE 매크로 및 스킬 세팅“ | Quickbar-Layout (LMB Quick Slice; RMB Whirlwind Slice → Insignia Explosion → Heart Gore → Ambush; E Shadowstrike → Infiltrate → Flash Slice; R Storm Rampage; Q Triniel's Dagger; 1 Illusive Clone; 2 Swift Contract; 3 Throw Shadowblade), Ingame-Makro „Quick Slice 50 – Quick Slice 50 – Savage Roar 80 (Skill-Queue AN)“, Boss-Opener | B |
| https://www.inven.co.kr/board/aion2/6449/3875 – Makro-Delay-Tipps | Standard-Delay 50 ms zu schnell (Eingaben verschluckt); Delay an niedrigster Kampfgeschwindigkeit ausrichten, sonst fällt das Makro nach Buff-Ende aus | B |
| https://www.inven.co.kr/board/aion2/6449/13185 – „인게임 매크로 설정과 체크방법“ | RMB-Linie (Insignia Explosion + Heart Gore) im Ingame-Makro mit 10 ms; Kontrolle über DPS-Meter | B |
| https://www.inven.co.kr/board/aion2/6449/113 und /6449/3856 – PvE-Assassin-Guides (Jan 2026) | „Illusive-Clone-CDR-Tree“: Heart Gore 16 (Reset), Insignia Explosion früh, Triniel's Dagger 10 (−10 % CD), Swift Contract; Ambush 16–20, Shadowstrike 16–20 (Crit-Dmg-Buff halten), Storm Rampage 20 optional; CDR multiplikativ | B |
| https://vortexgaming.io/en/postdetail/854915 – PvE Skill Build | Spezialisierungs-Picks je Skill (siehe assassin-meta.md), Passiv-Tiers, Stigma-Reihenfolge Illusive Clone > Swift Contract > Savage Fang > Triniel's Dagger 10 > Evasion Stance 5 > Throw Shadowblade | B |
| https://vortexgaming.io/en/postdetail/1009935 – One-Button-Makro & CDR | Ingame-Makro-Linie auf RMB: Insignia Explosion, Heart Gore, Savage Roar; Quick Slice auf eigener Taste; Lv-20-Reihenfolge: Heart Gore, Insignia Explosion, Quick Slice, Savage Roar; Rückenmarkierung im UI aktivieren; externe Hardware-Makros (G Hub) für Wechsel Normalangriff/Makro | B |
| https://vortexgaming.io/en/postdetail/589722 – Skill-System | Mastery: 3 von 5 Spezialisierungen wählbar, letzter Slot bei Skill-Lv 20; Skillpunkte bis Lv 10, darüber Ausrüstung/Arcana/Daevanion; 4 von 12 Stigmas (KR-Launch); Kombos auf Q/E | B |
| https://vortexgaming.io/en/postdetail/601044, /606019, /613372, /629825 | Frühe Kombos, Heart-Gore-Reset (Lv 16), Daevanion-Tipps, Skill-Level 11–20 über Arcana/Soul Imprint | B |
| https://vortexgaming.io/en/postdetail/980086, /739142, /605824, /654269 | Makro-Mechanik (Priorität, Mehrfacheintrag, halten), Ein-Tasten-Makro-Prinzip (4 Tasten in Folge), Animation-Cancel per LMB/RMB-Wechsel (+30–50 %), Ingame-Automatikangriff-Makro seit 28.01.2026, manuelle Eingaben haben Vorrang | B |
| https://www.gameple.co.kr/news/articleView.html?idxno=214499 | 3 von 5 Optionen öffnen bei Skill-Lv 8, die restlichen bei 12 und 16; Stigma-Optionen alle 5 Level automatisch | B |
| https://www.gametoc.co.kr/news/articleView.html?idxno=104096 | Spezialisierung 8/12/16/20, 3 von 5; 12 Stigmas, 4 Slots; Stigma-Shards; 6 Daevanion-Boards | B |

## Westliche Community-Guides

| Quelle | Entnommen | Verl. |
|---|---|---|
| https://aion2-assassin-guide.onrender.com/ – „AION 2 Assassin Field Manual“ (16.08.2026, Patch-Basis 12.08.2026) | Ziel-Level und Trait-Sets je Skill, Passiv-Ranking, Stigma-Reihenfolge auf 25, Buff-Zyklus, Prioritäten-Rotation, DPS-Diagnose, Gear/Stat-Matrix, Arcana-Reihenfolge, Makro-Screenshot (`/macro.png`: Ingame-Makro mit einem Slot „Insignia Explosion“ bei 10 ms + externer Wechsel Normalangriff/Makro), Patch-Historie Juli 2026 | B |
| https://gegebase.com/games/aion2/assassin_pve_guide | Ketten, Opener, Stat-Prio, Patch-Notizen 26.08. (Ketten +20 % PvE, Insignia Explosion +10 %, Lifesteal reduziert), 04.09. (Illusive Clone 120 s → 90 s, Spez. 4 überarbeitet), 09.09. (Seal-Slot) | B/C |
| https://aion2guide.de/klassen/assassine/ | Deutsche Seite; **deutsche Lokalisierung bis Release nicht öffentlich**, Klassenname „Assassine“ vorläufig; PvE-Stigma-Setup identisch zur KR-Meta | B |
| https://mein-mmo.de/aion-2-beste-klasse-fuer-den-einstieg-start/ | Deutsche Klassennamen (Assassine, Templer, Waldläufer, Kantor, Kleriker, Magier, Beschwörer) | C |
| https://www.iggm.com/news/aion-2-global-servers-dungeon-gameplay-changes-expeditions-gear-progression-stigma-slots | Global Season 1: **max. 4 Stigma-Slots**, 5er-Expeditionen, 10er-Raids, Cross-Faction, kein Heroic-Gear | C (unbestätigt) |
| https://expcarry.com/aion-2-stigma-daevanion-skill-upgrades-resets-progression | KR: Skillpunkte bis 10, freie Resets, Stigma-Cap 25 (Chapter 1), Global-Werte offen | C |
| https://aion2.wiki.fextralife.com/Daevanion_Boards, /Skills | 6 Boards (Nezekan 12, Zikel 20, Vaizel 30, Triniel 40, Ariel 45, Azphel 45), Knotenkosten grau 1 / grün 2 / blau 3 / orange 4; Skills-Fenster K, Daevanion U | C |
| https://ggwtb.com/blog/aion-2-macro-guide-set-up-dps-macros-for-pvp-pve | K → Makro-Tab; Taste unter Einstellungen → Tastenbelegung → Makro; Delay-Tabelle nach Ping; Ctrl+X DPS-Meter; 3–6 Skills; 12 Makro-Plätze (Suchtreffer) | C |
| https://www.mmom.com/aion-2-news/detail_aion-2-spiritmaster-early-game-macro-setup.html | Gleiche Mechanik, 4–6 Skills, lange CDs manuell | C |
| https://www.u4n.com/news/how-to-get-more-skill-points-in-aion-2.html | Skillpunkt-Quellen (Level, Empyrean Traces → Steine der Weisheit, Events, grüne Regionalquests → Daevanion) | C |
| https://boostroom.com/blog/aion-2-skill-setup-guide-hotbars-loadouts-and-rotation-basics | Allgemeine Hotbar-/Loadout-Prinzipien | C |
| https://mmo-news.audio/aion-2-stigma | Deutsche Begriffe; nennt Stigma-Freischaltung Lv 35 (widerspricht Spieldaten Lv 22/23) | D |
| u4gm.com, pvpbank.com, u4n.com Build-Guides | Nur zur Plausibilisierung; abweichende Skillnamen („Pattern Explosion“, „Quick Slash“) | D |

## Release & Struktur-Referenzen

| Quelle | Entnommen |
|---|---|
| https://mmos.com/news/aion-2-confirmed-global-launch-september, https://www.enduins.com/news/ncsoft-adjusts-global-pc-release-for-open-world-mmorpg-aion-2-to-october-5, https://aion2hub.com/guides/aion-2-release-date | Global-Release 05.10.2026, Early Access 30.09.2026 (Founder's Packs), Launch Scale Test 17.–18.09.2026, 10 Sprachen inkl. Deutsch, Steam + PURPLE |
| https://www.wowhead.com/guide/classes/rogue/assassination/rotation-cooldowns-pve-dps | Strukturvorlage: Navigation (Overview · BiS Gear · Rotation · Talent Builds · Consumables · Stats · Basics), Kernprinzipien als Bullet-Liste, Prioritätsliste mit Icons, Cooldown-Karten, „Advanced Tips“ |

## Icons

Skill-Icons sind Spielgrafiken von NCSOFT, geladen über das aion2pb-CDN (`scripts/fetch-icons.sh <klasse>`).
Nutzung nur für diesen privaten Guide.

---

## Ranger – Quellen (abgerufen am 18.09.2026, Skilldaten korrigiert am 18.09.2026)

### questlog.gg – offizielle Skilldatenbank (aktuelle Quelle der Wahrheit)

| Quelle | Typ | Entnommen | Verl. |
|---|---|---|---|
| https://questlog.gg/aion-2/en/db/skills/ranger | Skilldatenbank (tRPC-API `database.getSkills`/`getSkill`, per Browser-Pane abgerufen, da WebFetch an der JS-SPA scheitert) | Vollständige, offizielle Liste aller 35 echten Ranger-Skills (12 aktiv, 10 passiv, 13 Stigma) mit numerischen API-IDs, Kategorie (active/passive/stigma), wörtlichem Tooltip-Text, Cooldown (ms), Reichweite, Waffenanforderung und allen fünf Spezialisierungs-Effekten je aktivem Skill | **A** (offizielle Tooltip-/Mechanik-Daten, gleiches Niveau wie der Assassin-Datensatz) |

**Wichtigster Befund:** Der zuvor in diesem Guide zentrale Skill „Rapid Fire" taucht in diesem
offiziellen 35-Skill-Roster **nicht auf** – er wurde von einer früheren, unzuverlässigen
WebFetch-Zusammenfassung fabriziert (das Tool warnte selbst, Ergebnisse könnten „summarized"
und ungenau sein). Ebenso nicht im Roster: die 10 zuvor als „special" gelisteten Skills
(Afterimage, Arrow of Space-time, Dust Arrow, Eye of Rapid Burst, Guerilla Strike, „Hunter's
Resolve (aktiv)", Impact Kick, Lightning Arrow, Spiral Arrow, Tempest Arrow als eigenständiger
Skill) sowie „Shackling Arrow". „Tempest Arrow" existiert, aber nur als Kettenfähigkeit, die
Snipes Spezialisierung 5 (Skill-Level 16) freischaltet – laut Snipes eigenem API-Tooltip
(„Adds [Tempest Arrow] Chain Skill"). Alle Beschreibungen, Cooldowns, Reichweiten und
Spezialisierungs-Optionen in `data/aion2/ranger/skills.json` wurden am 18.09.2026 durch die
Werte aus dieser Quelle ersetzt.

### Frühere / ergänzende Quellen (vor der Korrektur, teils überholt)

Verlässlichkeit wie oben. **Wichtig:** `aion2.app` lieferte für den Ranger beim Abruf nur
eine Skill-Übersicht (Name/Level/CD/MP/Icon), keine Tooltip-Texte – wird nach der Korrektur
nur noch als Quelle für die (weiterhin unbestätigten) Charakter-Freischalt-Level genutzt, nicht
mehr für Beschreibungen/Spezialisierungen.

| Quelle | Typ | Entnommen | Verl. |
|---|---|---|---|
| https://aion2.app/db/skills?class=Ranger | Skill-Übersicht (nur Namen/Level/CD/MP/Icon-Codes, keine Tooltips) | 48 Ranger-Einträge (inkl. der inzwischen widerlegten Rapid-Fire-/special-Einträge): Name, Freischalt-Level, Abklingzeit, MP, Icon-Code | B (Freischalt-Level unbestätigt; Roster-Vollständigkeit durch questlog.gg widerlegt) |
| https://aion2hub.com/classes/ranger | Klassenseite | Rolle „long-range bow DPS, kiting/bursting", Namensliste 37 aktiv/10 passiv (enthielt ebenfalls „Rapid Fire" – durch questlog.gg widerlegt) | C (Roster-Angabe falsifiziert) |
| https://aion2hub.com/builds/ranger/ranger-pve-dps-kxve00 | Build-Datenbank | Statprioritäten (Attack, Crit, Accuracy, Penetration), Pantheon-Verteilung (Beispiel-Build) | B |
| https://questlog.gg/aion-2/en/classes/ranger | Klassenseite | Abruf per WebFetch ohne Inhalt (nur Metadaten) – die Skilldatenbank-Unterseite (siehe oben) wurde stattdessen per Browser-Pane erfolgreich abgerufen | – |

### KR-Community (Inven, savetip.co.kr)

| Quelle | Entnommen | Verl. |
|---|---|---|
| https://www.inven.co.kr/board/aion2/6450/4009 – „궁성 가이드" | Snipe/Rapid-Fire-Spezialisierungs-Sockets je Breakpoint, Stigma-Priorität (Bow of Blessing > Explosive Arrow > Arrow Storm > Vaizel's Authority optional), Arcana-Setup (Chalice/Compass/Mirror), Soul-Imprint-Prioritäten, Hit-Richtwert 1350–1400, Animation-Cancel-Empfehlung „Wechselklicken statt Makro, Skill-Queue aus" | B |
| https://www.inven.co.kr/board/aion2/6450/808 – „스킬세팅, 실전 플레이 포함 궁성 공략" | Nur Board-Metadaten/Video-Kapitel abrufbar, kein Volltext | C |
| https://game.savetip.co.kr/aion2-archer-pve-guide-build/ | Skilltree-Prioritäten (Left-Click/Right-Click-Spezialisierungen), Stigma-Reihenfolge „Bayezel > Revitalize > Griffin > Support > Explosion" (andere Patch-Momentaufnahme als Inven), Davanion-Passiv-Priorität 2/4/5/7/8/10, Groggy-Rotation | B |
| https://game.savetip.co.kr/aion2-archer-guide-skill-build/ | Ausrüstungs-Priorität (Waffen-Tier zuerst), Stigma-Hinweis „Level variiert, nicht pauschal", Passiv-Ranking (Concentrated Eye > Hunter's Resolve/Spirit > …) | B |

### Vortex Gaming

| Quelle | Entnommen | Verl. |
|---|---|---|
| https://vortexgaming.io/en/postdetail/728615 – Patch-Analyse | Stigma-Set „Vaizel's Authority (Byzel), Bow of Blessing (Blessed Bow), Griffon Arrow auf Lv 20, Supporting Fire Lv 15 reicht"; Perfect-Stat-Begründung (kaum Gegner-Resistenz, wirkt auf Waffenschaden); Buffs an Illusory/Explosive Arrow erwähnt | B |
| https://vortexgaming.io/en/postdetail/696596 – Makro-Guide | Kampfgeschwindigkeits-Obergrenze 88,1 % (durch Gale-Arrow-Passiv-Effekt erreichbar); Makro-Setup „nur Rapid Fire im Makro, Snipe auf Seitentaste, Rechtsklick manuell spammen"; DPS-Steigerung 2,43 → 2,69 im Test | B |

### Westliche Aggregator-Guides (nur zur Plausibilisierung, teils widersprüchliche Namen)

| Quelle | Entnommen | Verl. |
|---|---|---|
| https://gamerstogether.cz/en/aion-2-ranger-build-guide/ | Nennt „Deadshot +7 % PvE-Schaden (Juli 2026)", „Explosive Arrow +15 % PvE-Schaden", warnt selbst: „englische Skillnamen variieren je Quelle" | C |
| https://aion2base.com/classes/ranger/ | Rolle/Mechanik allgemein, „Accuracy vor Schadensspitzen priorisieren" | C |
| https://www.pvpbank.com/best-aion-2-ranger-builds | Skillnamen weichen ab („Griffin Arrow", „Piercing Arrow", „Marking Arrow", „Arrow Rain") – nur für grobe Rollen-Einordnung genutzt, nicht für Namen übernommen | D |
| https://www.u4n.com/news/aion-2-ranger-build-guide-2026.html | Skillnamen weichen ab („Bagel/Baseel Power", „Blink/Dash") – nicht für Namen übernommen, nur Rollen-Flavour | D |

### Namensabgleich

Der Abgleich koreanischer Originalnamen zu den aion2.app-Namen (z. B. 저격 = Snipe,
조준 화살 = Deadshot) steht mit Begründung in `ranger-meta.md`, Abschnitt 0.

## Gladiator – Quellen (abgerufen am 18.09.2026)

### questlog.gg – offizielle Skilldatenbank (Quelle der Wahrheit für Tooltips)

| Quelle | Typ | Entnommen | Verl. |
|---|---|---|---|
| https://questlog.gg/aion-2/en/db/skills/gladiator | Skilldatenbank (tRPC-API `database.getSkills`/`getSkill`, per Browser-Pane abgerufen) | Vollständige, offizielle Liste aller 35 echten Gladiator-Skills (12 aktiv, 10 passiv, 13 Stigma) mit numerischen API-IDs, Kategorie (active/passive/stigma), wörtlichem Tooltip-Text, Cooldown (ms), Reichweite, Waffenanforderung (durchgängig `greatsword`) und allen fünf Spezialisierungs-Effekten je aktivem Skill (bzw. fünf Rang-Stufen je Stigma/Passiv, in `skills.json` nur für aktive Skills als `specs` übernommen) | **A** (offizielle Tooltip-/Mechanik-Daten, gleiches Niveau wie Assassin- und korrigierter Ranger-Datensatz) |

Technischer Hinweis: Die API liefert Beschreibungstext mit HTML-Platzhaltern
(`<span style="color:#FCC78B">{se_dmg:<id>:SkillUIMinDmgsum}-{se_dmg:<id>:SkillUIMaxDmgsum}</span>`)
statt fertiger Zahlen – wie beim Assassin/Ranger zu `X-X` normalisiert, da die tatsächlichen
Schadenswerte vom Skill-Rang und der eigenen Ausrüstung abhängen und nicht statisch aus der
API auslesbar sind.

### aion2.app – Freischalt-Level (erstmals vollständig bestätigt)

| Quelle | Typ | Entnommen | Verl. |
|---|---|---|---|
| https://aion2.app/db/skills?class=Gladiator | Skill-Übersicht (Name, Freischalt-Level, keine Tooltips) | Freischalt-Level für alle 35 Gladiator-Skills, 1:1 mit den questlog.gg-Skillnamen abgeglichen (keine Namensabweichungen gefunden) | **B**, aber vollständig und mit A-Quelle abgeglichen – daher in `skills.json` als `unlock_level_confirmed: true` markiert, anders als beim Ranger-Datensatz (dort nur teilweise abgeglichen, weiterhin `false`) |

### Rollen-Einordnung (Bruiser/Off-Tank statt Haupttank)

| Quelle | Entnommen | Verl. |
|---|---|---|
| https://aion2hub.com/classes/gladiator | Rolle „Tank/DPS hybrid position", „aggressive, in-your-face bruiser that closes distance and unleashes wide arcing greatsword swings … healing off the damage it deals to outlast opponents"; Waffe Greatsword; Kernfähigkeiten Crushing Wave/Frenzied Wave/Blade Dance (Flächenangriffe), Blade Toss (Gap-Closer), Focused Block (Mitigation) | B |
| https://aion2wiki.com/classes/gladiator | Rolle „sustained melee frontline" mit „high attack and defense … enough health and protection to act as a secondary tank"; Hinweis, Skillbehavior/Balance aus dem Original-Aion nicht übertragbar; betont Positionierung/Encounter-Wissen vor festen Rotationslisten | B |
| Skilltext-Eigenrecherche (questlog.gg-Daten) | Zwei Skill-Tooltips referenzieren wörtlich die Templer-Klasse als Haupttank-Referenz: `Rage Burst` („Wounded does not stack with the Shrink effect from the Templar skill [Taunt]") und `Experienced Counterstrike` („does not stack with Templar's [Fury] effect") – Indiz, dass der Templer die dedizierte Tank-Klasse ist und der Gladiator explizit als Sekundär-/Off-Tank konzipiert wurde | A (Primärquelle: die Skilldaten selbst) |

### Video-Quelle (vom Nutzer verlinkt)

| Quelle | Entnommen | Verl. |
|---|---|---|
| https://www.youtube.com/watch?v=xZk4sS45vdo – „AION 2 Gladiator Macro Guide \| Basic Setup & DPS Rotation" (Kanal „Sen", ~14 Tsd. Aufrufe) | Titel, vollständige Videobeschreibung und Kapitelmarken per Browser-Pane ausgelesen (`ytInitialData`/`ytInitialPlayerResponse`): Thema ist der Vergleich von manuellem Spiel vs. Ingame-Makro für die Gladiator-DPS-Rotation, mit Kapiteln „Intro + abilities explanation", „DPS TEST – without Macro", „DPS TEST – with Macro", „Macro setup". Automatischer Transkript-Abruf (`timedtext`-API) lieferte zum Recherchezeitpunkt eine leere Antwort (vermutlich abgelaufene Signatur) – nur Titel/Beschreibung/Kapitel ausgewertet, kein Volltranskript | C (Metadaten zuverlässig, aber kein Volltext; als ergänzende, nicht als primäre Quelle für den Reiter Makros verwendet) |
| https://www.youtube.com/watch?v=EAjD1naPlU0 – „AION 2 Gladiator PVE Build for Skills & Stigmas \| Beginners Guide" | Über WebSearch gefunden, nicht vom Nutzer verlinkt und nicht ausgewertet (aus Zeitgründen nicht abgerufen) – als möglicher weiterer Beleg für künftige Aktualisierungen notiert | – (nicht abgerufen) |

### Weitere Community-Quellen (Plausibilisierung, nicht für Skilldaten verwendet)

| Quelle | Entnommen | Verl. |
|---|---|---|
| https://aion2.wiki.fextralife.com/Gladiator | In der WebSearch-Trefferliste aufgeführt; WebFetch-Abruf durch `robots.txt`-Fehler blockiert, keine Inhalte entnommen | – (nicht abgerufen) |
| https://vortexgaming.io/en/postdetail/611533 – „[Aion 2] Gladiator Skill Guide: Complete Analysis of Skills, Passives, and Stigmas" | In der WebSearch-Trefferliste aufgeführt, nicht abgerufen (questlog.gg-API lieferte bereits vollständige, verlässlichere Skilldaten) | – (nicht abgerufen) |
| https://www.exitlag.com/blog/aion-2-gladiator-build/, https://khaganate.org/en/blog/aion-2-gladiator-guide, https://www.gamesolusi.com/2026/07/aion-2-gladiator-class-guide.html, https://www.aoeah.com/news/4215--aion-2-best-builds--skills-for-each-class-solo-pvp--pve | In der WebSearch-Trefferliste aufgeführt, nicht einzeln abgerufen | – (nicht abgerufen) |
