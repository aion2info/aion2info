# Aion 2 – Spielsysteme rund um Skills (Stand 16.09.2026)

Alle Angaben beziehen sich auf den KR/TW-Client (Chapter 1, Level 50). Abweichungen für
den Global-Release (05.10.2026) sind im Abschnitt „Global vs. KR“ gesammelt. „Abgeleitet“
markiert Schlüsse aus mehreren Quellen, die nicht wörtlich belegt sind.

## 1. Skill-Kategorien

| Kategorie | Beschreibung | Assassin |
|---|---|---|
| **Mastery-Skills, aktiv** | Klassenskills, automatisch beim Erreichen des Charakterlevels gelernt. Leveln mit Skillpunkten. | 12 (Quick Slice, Savage Roar, Shadowstrike, Ambush, Heart Gore, Storm Rampage, Whirlwind Slice, Flash Slice, Infiltrate, Shadow Fall, Insignia Explosion, Defiance) |
| **Mastery-Skills, passiv** | Dauerhafte Boni, ebenfalls mit Skillpunkten gelevelt. | 10 (Heightened Sixth Sense, Exploit Weakness, Apply Poison, Rear Smite, Assault Stance, Impact Hit, Ambush Stance, Defense Break, Revitalization Contract, Determination) |
| **Ketten-Skills (Chain 2/3, 3/3)** | Folgeschläge innerhalb eines Skills, gleiche Taste, kein eigener Slot. | Quick Slice → Breaking Slice → Swift Slice; Savage Roar → Savage Back Kick → Savage Smash |
| **Bedingte Skills** | Nur nutzbar, wenn eine Bedingung erfüllt ist. | Heart Gore (nach kritischem Treffer), Storm Rampage (Ziel in Stagger), Shadow Fall (Ziel betäubt; Spez. 5: auch geblendet), Infiltrate (nach Dodge / im Flug) |
| **Stigma-Skills** | Zusätzliche Skills in eigenen Slots, ab Charakterlevel 22/23 (siehe unten), Leveln mit Stigma-Shards. | 13 |
| **Spezialisierungs-Ketten** | Zusätzliche Folgeskills, die eine Spezialisierung freischaltet. | Defiance Spez. 1 → Storm Slice; Infiltrate Spez. 4 → Dark Strike; Throw Shadowblade Lv 5 → Shadowblade Pursuit; Aerial Bind Lv 10 → Aerial Slaughter |
| **Daevanion-/Sonderskills** | Orange Knoten auf Daevanion-Boards bzw. Varianten. | Frenzied Accord, Surging Bloodlust, Prepare to Assassinate, Stigma-Variante von Apply Poison |

Freischalt-Level der Assassin-Skills (Skill-API): Lv 1 Quick Slice, Savage Roar,
Shadowstrike, Heightened Sixth Sense · 3 Ambush · 4 Heart Gore · 5 Storm Rampage ·
6 Exploit Weakness · 7 Whirlwind Slice · 8 Flash Slice · 9 Apply Poison · 10 Infiltrate ·
11 Rear Smite · 12 Shadow Fall · 13 Assault Stance · 14 Insignia Explosion · 15 Impact Hit ·
16 Defiance · 17 Ambush Stance · 21 Defense Break · 22 alle 13 Stigmas (Anforderung im
Skill) · 23 Revitalization Contract · 25 Determination.

## 2. Skillpunkte (Mastery-Punkte) und Skill-Level

- Skillpunkte kommen aus **Level-Ups**, aus **Steinen der Weisheit** (Empyrean/Lord
  Traces an Monolithen, Shugo-Festa-Shop, Nightmare-Shop, je bis Stufe 4) und aus
  **Einmalinhalten** (Chapter 1). KR-Gesamtbudget: **423 Punkte** (Inven, 2026); der
  Inven-Simulator rechnete im Januar 2026 noch mit **396**.
- Mit Punkten geht jeder Skill bis **Stufe 10**. Stufe 11–20 kommen aus Daevanion
  (blaue Knoten = aktive Skills, grüne = passive), Ausrüstung (Soul Imprint; Ringe für
  aktive, Rüstungsteile für passive Skills) und Arcana (Scroll/Parchment = aktiv,
  Chalice/Grail = passiv). Anzeige-Maximum in der API: 40.
- **Kosten pro Stufe**: nicht veröffentlicht; laut KR-Post reichen 423 Punkte für
  11 aktive + 9 passive Skills auf Stufe 10 (ein Skill bleibt auf 1). Abgeleitet: rund
  20 Punkte pro Skill für Stufe 1→10, Kosten steigen mit der Stufe. Während des
  Levelns reicht das Budget deshalb nur für wenige Skills auf 8–10 – die Reihenfolge
  zählt.
- **Resets** sind in KR kostenlos (Mastery und Stigma); Daevanion-Resets pro Knoten kosten Kinah.
- Skill-Fenster: Taste **K**. Daevanion: **U**.

## 3. Spezialisierung (특화)

Jeder aktive Mastery-Skill hat **5 Optionen** und **3 Slots**.

| Skill-Stufe | Was passiert |
|---|---|
| 8 | Optionen 1–3 werden verfügbar, **Slot 1** öffnet |
| 12 | Option 4 wird verfügbar, **Slot 2** öffnet (abgeleitet aus Trait-Sets der KR-Guides) |
| 16 | Option 5 wird verfügbar (meist die stärkste, verändert den Skill) |
| 20 | **Slot 3** öffnet (Vortex: „3 von 5 wählbar, letzter Slot bei 20“) |

Belege: gameple.co.kr („3 der 5 Optionen öffnen bei 8, die übrigen bei 12 und 16“), Vortex
589722 („3 von 5, letzter Slot bei 20“), Field Manual/Vortex-Trait-Sets (zwei Traits bei
Stufe 12/16, drei bei 20). Die Option **kann jederzeit gewechselt** werden; Spezialisierungs-
werte skalieren mit dem Skill-Level (Quick Slice HP-Absorb 0,7 % bei Lv 1 → 1,5 % bei Lv 20).
Passive Skills haben keine Spezialisierung, sie skalieren nur mit dem Level.

**Stigma-Skills** haben stattdessen fünf Spezialitäten, die **automatisch** bei Stigma-Level
5 / 10 / 15 / 20 / 25 aktiv werden und erhalten bleiben (keine Wahl).

## 4. Stigma

- Freischaltung: Stigma-Quest ab ca. Charakterlevel 20, Stigmas nutzbar ab **Lv 22/23**
  (Skill-API: Lv 22; aion2hub-Leveling-Guide: Lv 23). Der Assassin hat 13 Stigma-Skills.
- Slots: KR-Launch 4, seit März 2026 5, seit Chapter 1 (Juli 2026) **6**. **Global Season 1: 4**
  (IGGM, unbestätigt). Die Guides sind deshalb auf 4 Slots geschrieben, mit Empfehlung für Slot 5/6.
- Leveln mit **Stigma-Shards** (KR): Stufe 1–5 je 1 Shard, 6–10 je 2, 11–15 je 4, 16–20 je 8
  → 75 Shards bis Lv 20, dazu Abyss-Punkte (100 k bis 5, 375 k bis 10, 875 k bis 15,
  1,875 Mio bis 20). Lv 21–25 (seit Chapter 1) brauchen höherwertige Shards.
- Shard-Quellen: Abyss-Punkte-Shop (25 000 AP), Abyss-Bosse, Shugo-Spiele, Versorgungs-
  aufträge, Aufstiegsprüfung (instabile Shards, per Morphing wandelbar), saisonale Inhalte.
- Stigma-Skills kosten je **1 Stigma-Punkt** zum Ausrüsten (API-Feld „Stigma Points: 1“).

## 5. Daevanion-Boards

| Board | Charakterlevel | Schwerpunkt |
|---|---|---|
| Nezekan | 12 | Combat Speed, Cooldown-Reduktion |
| Zikel | 20 | Damage Boost, Damage Tolerance |
| Vaizel | 30 | Critical Damage Boost / Tolerance |
| Triniel | 40 | Multi-Hit Chance / Resist |
| Ariel | 45 | PvE Damage Boost / Tolerance |
| Azphel | 45 | PvP Damage Boost / Tolerance |

Knotenkosten: grau (Stats) 1 · grün (passive Skill-Level) 2 · blau (aktive Skill-Level) 3 ·
orange (Sonderskill) 4 Daevanion-Punkte. Bis Lv 45 ca. 400 Punkte aus Level-Ups, Verstecken
(Daevanion-Kristalle), grünen Regionalquests und Einmalinhalten. Faustregel der KR-Guides:
Skill-Knoten der Kern-Skills zuerst (Breakpoints 12/16/20 der aktiven Skills), Stat-Knoten
auf dem Weg mitnehmen, nicht gleichmäßig verteilen.

## 6. Arcana (Endgame, KR)

Acht Teile, aus Transzendenz-Dungeons. Für den Assassin: **Scroll** (Quick Slice, Heart Gore,
Insignia Explosion), **Compass** (Savage Roar, Storm Rampage, Defiance), **Chalice** und
**Scales** (passive Skill-Level: Rear Smite, Assault Stance, Exploit Weakness), **Key**
(Weapon Damage, Back Attack Damage, Critical Damage), **Hourglass** (PvE-Resistenz).
Aufwertungsreihenfolge laut Field Manual: Scroll → Compass → Chalice → Scales. Ob Global
zum Start alle Slots hat, ist offen.

## 7. Quickslots und Slot-Linien („라인“)

- Standard-Leiste: Slots **1–8**, dazu **Q** und **E**, **linke** und **rechte Maustaste**;
  Stigma-Skills belegen ebenfalls Slots (laut Aggregatoren „4 Skills + 4 Stigma“ als
  Grundlayout, tatsächlich frei belegbar). Tasten sind frei belegbar (Einstellungen →
  Tastenbelegung).
- **Jeder Slot enthält eine Linie aus bis zu 4 Skills mit Priorität 0 → 1 → 2 → 3**
  (Dev-Stream #5, Inven 6444/1899). Beim Tastendruck wird der erste Skill der Linie
  genutzt, der gerade verfügbar ist (nicht auf Abklingzeit, Bedingung erfüllt); ist er
  es nicht, fällt die Eingabe zum nächsten durch. Bedingte Skills (Heart Gore, Whirlwind
  Slice, Shadow Fall) stehen in KR-Layouts deshalb **oben**, Dauerfüller unten.
- Ketten-Folgeschläge (2/3, 3/3) laufen automatisch auf derselben Taste weiter.
- Dieses Linien-System ist das „Skills übereinander anordnen, die nacheinander
  abgespielt werden“: eine Taste, eine Prioritätsliste.

## 8. Ingame-Skill-Makro (스킬 매크로)

Eingeführt in KR mit dem Update vom 28.01.2026 („Automatikangriff-Makro“).

- Öffnen: **K → Reiter „Makro“ (oben rechts)**. Makro-Taste unter **Einstellungen →
  Tastenbelegung → Makro** (üblich: rechte Maustaste, Seitentaste oder freie Zahl).
  Es gibt mehrere Makro-Plätze (Aggregator: 12).
- Ein Makro ist eine **Liste von Einträgen**; jeder Eintrag verweist auf einen
  **Quickslot** (nicht auf einen einzelnen Skill) und hat ein **Delay in ms** sowie die
  Option **Skill-Queue (스킬 예약) an/aus**. Ein Slot-Eintrag nutzt beim Abspielen den
  ersten verfügbaren Skill der Slot-Linie.
- Ablauf: Solange die Makro-Taste **gehalten** wird, läuft die Liste zyklisch durch.
  **Manuelle Eingaben haben Vorrang** (unterbrechen das Makro nicht dauerhaft). Skills auf
  Abklingzeit werden übersprungen bzw. mit Skill-Queue vorgemerkt.
- **Delay**: KR-Spitzenspieler nutzen 10 ms für die Kern-Linie; typische Alternativen
  50/50/80 ms. Zu kleines Delay verschluckt Eingaben, zu großes kostet Tempo. Delay an
  der **niedrigsten** Kampfgeschwindigkeit ausrichten (ohne Buffs), sonst fällt das Makro
  nach Buff-Ende aus. Ping-Tabelle (ggwtb): < 50 ms Ping → 5–10 ms, 50–100 → 10–20,
  100–150 → 20–30, darüber testen.
- Prinzip „Ein-Tasten-Makro“ (Vortex 739142): 1. Normalangriff-Slot, 2. Slot mit kurzen
  CDs, 3. schwerer Angriff, 4. Reserve – zyklisch; liefert ~90 % der manuellen Leistung.
  Mehrfacheinträge desselben Slots erhöhen dessen Anteil.
- Test: **Ctrl + X** öffnet den eingebauten DPS-Meter (Schaden je Skill); Trainingspuppe im
  Legions-/Gildenhaus; immer nur eine Änderung testen.

## 9. Animation-Cancel (평타 캔슬)

Abwechselndes Drücken von linker Maustaste (Normalangriff, beim Assassin die Quick-Slice-
Kette) und rechter Maustaste/Skill-Taste bricht die Nachverzögerung des Normalangriffs ab.
Vortex misst +30–50 % Schaden gegenüber reinem Klicken. KR-Spieler kombinieren dafür oft
ein Hardware-Makro (Logitech G Hub, Razer) mit dem Ingame-Makro (Screenshot im Field
Manual: `[` = Normalangriff, `]` = Ingame-Makro, 10 ms). **Externe Automatisierung ist
regelseitig eine Grauzone** („do not assume external automation is permitted“); der Guide
beschreibt nur das Ingame-Makro und das manuelle Wechselklicken.

## 10. Global vs. KR (Stand der Vorabinformationen)

| Thema | KR/TW (Sept 2026) | Global Season 1 (angekündigt/erwartet) |
|---|---|---|
| Release | seit 19.11.2025 | Early Access 30.09.2026, Release 05.10.2026 |
| Level-Cap | 50 (Chapter 1) | offen (Beta: 37; Launch vermutlich 45 oder 50) |
| Stigma-Slots | 6 | 4 |
| Stigma-Max-Level | 25 | vermutlich 20 |
| Arcana-Slots | 8 | offen |
| Gruppen | 4er-Expeditionen, 8er-Raids | 5er / 10er, Cross-Faction möglich |
| Balance | Patches bis 09.09.2026 (siehe unten) | älterer Stand möglich |
| Sprachen | KR/ZH | 10 inkl. Deutsch |

## 11. Patch-Historie mit Assassin-Bezug (KR, 2026)

| Datum | Änderung |
|---|---|
| 28.01. | Ingame-Skill-Makro (Automatikangriff) eingeführt |
| 01.07. | Chapter 1: Level 50, Stigma-Level 25, Anhänger, erweiterte Arcana |
| 08.07. | Illusive Clone Spez. 5: −1 s CD pro kritischem Rückenangriff; Throw Shadowblade ohne MP-Kosten; Shadow-Walk-Bugfixes |
| 22.07. | Evasion Stance Spez.: +20 % Bewegungstempo nach Ausweichen; Lifesteal-Effekte nur noch Einzelziel |
| 29.07. | Defiance nicht mehr von CD-Reduktion betroffen |
| 26.08. | Ketten-Skills +20 % PvE-Schaden, Insignia Explosion +10 %, Lifesteal deutlich reduziert |
| 04.09. | Illusive Clone CD 120 s → 90 s (API zeigt 90 s), Spez. 4 zu „50 % Chance auf Zusatzschaden bei Krit“ |
| 09.09. | Neuer Ausrüstungsslot „Seal“ |
