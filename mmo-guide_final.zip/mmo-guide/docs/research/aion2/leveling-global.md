# Aion 2 – Leveling & Global-Start (Recherche, Stand 19.09.2026)

Ergänzt `systems.md` (Abschnitt „Global vs. KR") um klassenübergreifende Leveling-,
Skillpunkt- und Alt-Charakter-Themen für den Global-Release (Early Access 30.09.,
Release 05.10.2026). Verlässlichkeit wie in `sources.md`: A = offiziell/Spieldaten,
B = etablierte Community, C = Aggregator, D = widersprüchlich/nur Hinweis.

## 1. Level-Cap & Dungeon-Freischaltungen Global Season 1

| Quelle | Aussage | Verl. |
|---|---|---|
| mmo-codex.com/articles/aion-2-leveling-guide/ | Global-Release-Level-Cap **45**. Launch Scale Test (17./18.09.) hatte Cap **37**, PvP/Abyss/Battlegrounds/Ascension Trial/Nightmare-Dungeons erst ab 45 gesperrt. | B |
| iggm.com/news/aion-2-global-servers-dungeon-gameplay-changes… | Dungeons schalten bei Charakterlevel **20, 28, 35, 45** frei. Nur 3 Schwierigkeiten (1–3 Sterne) zum Start, **kein Heroic** in Season 1. Item-Level-Richtwerte: 800 für 1★, 2.200+ für 3★. Expeditionen 4→**5 Spieler**, Sanctuary/Raids 8→**10 Spieler**, Cross-Faction-Gruppen möglich. **Stigma-Slots auf 4 begrenzt** (Season-1-Beschränkung, KR/TW hat 6). | B |
| topgamecarry.com/guides/aion-2-endgame-guide/ | Global-Cap zum Zeitpunkt der Recherche nicht final angekündigt; Guide geht von „nicht 1:1 KR-Kopie" aus. Endgame-Loop: Expedition-Dungeons (Gear/Mats/Währung), Timed-Challenge-Dungeons (Arcana-Karten, Stigma-Mats), Sanctuary-Raid (bestes Gear, wöchentliches Lockout), PvP-Tracks (Abyss, stat-normalisierte Battlegrounds). | B |

## 2. Federn (Feathers), Amulett/Monolith-System und Skillpunkte

**Bestätigt durch zwei direkte Global-Client-Gameplay-Videos** (YouTube, „NoBS Game
Guides – Aion 2 Beginners Guide" [n4uaoeGlVb8] und „Don't Start Leveling Until You
Watch This" [AZMeJDtfRc4], beide A/B – direkte Aufnahmen aus dem Global-Client,
19.09.2026 ausgewertet): Die Nutzerangabe war **korrekt**. Federn geben im
Global-Release **keine Skillpunkte**. Der tatsächliche Mechanismus:

- Federn liegen weiterhin in der Welt verteilt und werden an **Monolithen**
  abgegeben (z. B. „Verteron Monolith").
- Das Auffüllen eines Monolithen schaltet aber **keine Weisheitssteine/Skillpunkte**
  frei, sondern eine **Amulet Enhancing Scroll**.
- **Amulett und Gürtel sind permanente, einzigartige Ausrüstungsteile** – man erhält
  je eines und ersetzt sie nie durch ein Drop-Upgrade, sondern wertet dasselbe Teil
  dauerhaft auf:
  - Das **Amulett** wird über die Amulet Enhancing Scrolls (aus Monolithen) sowie
    per **„Substance Morph"** in die nächste Raritätsstufe verwandelt
    (grün → blau → gold).
  - Der **Gürtel** wird über Material aus **Strongholds** aufgewertet – auf der
    Weltkarte durch Fragezeichen-Lager markiert.
- Die eigentlichen **Skillpunkte** kommen stattdessen aus **Level-Ups** und aus
  **Sealed Dungeons**. Sealed Dungeons skalieren auf das aktuelle Charakterlevel,
  geben normale Skillpunkte **und** die Währung für die Daevanion-Bäume.
  Zusätzliche Skillpunktquellen bleiben: Shugo-Festa-/Nightmare-Shop (Steine bis
  Stufe 4), Chapter-1-Einmalinhalte (siehe `systems.md`, KR-Gesamtbudget 423, Stand
  Januar 396).
- In **Sealed Dungeons** ist die **Energy-Ressource** der Begrenzer fürs Bosse-Looten
  (limitiert pro Tag) – die Videos empfehlen, jeden Boss zu looten statt zum
  Endboss zu rushen, weil so der Gesamt-Loot pro Energie maximiert wird.

Damit ist die Alt-spezifische Abschwächung aus vortexgaming.io/en/postdetail/606714
(Feld-Federn für Zweitcharaktere auf **1/4 reduziert**, KR-Patch „2. Dezember" 2025)
weiterhin separat gültig, betrifft aber jetzt die Amulett-Progression über Federn,
nicht mehr Skillpunkte direkt.

**Daevanion-Ability-Level-Cap (präzisiert):** Jeder Daevanion-Baum enthält jede
Fähigkeit genau einmal und trägt pro Baum maximal **+1** Skill-Level bei; bei
**4 Bäumen** ergibt das **+4** zusätzliche Skill-Level über die reguläre Mastery-
Obergrenze von 10 hinaus, also **Skill-Level 14 als Daevanion-Cap**. Die restlichen
Stufen bis zum theoretischen Maximum von 20 kommen ausschließlich über
**Ausrüstungs-Stat-Rolls** („+1 Ability Level" statt eines normalen Stats auf einem
Gear-Slot, per Reset-Funktion re-rollbar). Die Begriffe „Arcana" und „Soul Imprint"
(Ring-System) tauchen in den beiden Videos nicht auf – vermutlich spätere
Endgame-Systeme, die im Beginner-Content nicht behandelt werden; kein Widerspruch zu
`systems.md`, aber als Terminologielücke vermerkt.

**Empfehlung für den Guide:** Federn weiterhin im Vorbeigehen mitnehmen (sie speisen
jetzt die Amulett-Progression), aber die Skillpunkt-Planung ausschließlich auf
Level-Ups + Sealed Dungeons stützen. Sealed Dungeons pro Region nicht auslassen –
sie sind jetzt die zentrale Skillpunkt- und Daevanion-Währungsquelle, nicht nur ein
optionaler Gear-Bonus.

## 2b. Empfohlene Client-Einstellungen (aus Video „NoBS Game Guides", Kapitel 7)

- **Auto Target Upon Skill Use** aktivieren – automatisches Anvisieren beim
  Skilleinsatz.
- **Pursue Targets with Skill Activation** aktivieren – Charakter bewegt sich beim
  Skilleinsatz automatisch ins Reichweitenfenster.
- **Target Scanning**: Scan-Richtung und Prioritätsreihenfolge auf die eigene
  Spielweise abstimmen (z. B. nächstes Ziel vor dem Bildschirm zuerst).
- **Buff-Auto-Use auf „In Combat"** stellen, damit Buffs automatisch beim
  Kampfeintritt aktiviert werden, statt manuell vor jedem Pull.
- **Display Boss Orientation auf „All"** – zeigt Blickrichtung/Ausrichtung von
  Bossen durchgehend an, wichtig für Attacken-Tells.
- **Eigene Taste für „Defiance"** (Trotz) getrennt von der Leertaste/Sprung
  vergeben, um versehentliches Auslösen im falschen Moment zu vermeiden.

Zusätzlicher Tipp aus demselben Video: Ausrüstung vor Erreichen des Max-Levels
**nicht über +1/+2 hinaus aufwerten** – der Weg zum Cap ist so schnell, dass
Zwischen-Gear ohnehin in Kürze ersetzt wird.

## 3. Alt-Charaktere (Twinks)

| Quelle | Aussage | Verl. |
|---|---|---|
| mmo-codex.com/articles/aion-2-alts-guide/ | **Account-weit:** Collections (Titel, Pets, Pantheon-Gemälde) inkl. deren Statboni. **Pro Charakter:** Odyle-Energie + ihr Shop, Feld-Kinah-Tageslimit, Nightmare-Einträge (2/Tag), Ascension Trial (3/Woche), Shugo-Festa-Schlüssel, Dungeon-Cube-Einträge. **Geteilt über den ganzen Account, aber gedeckelt:** die wöchentlichen Solo-Dungeons (Bio-Research/Odylium) – nur **14 Einträge insgesamt für den ganzen Roster**, skaliert NICHT mit mehr Chars. Empfehlung: meist **1 Alt**, aktive Spieler mit sauberer Conquest-Routine auf dem Main **2**, ab **3+ Alts kontraproduktiv**. Effizientes Alt-Leveling: gelbe Hauptquest rushen (~6 h auf 45), Sealed Dungeons/Strongholds auslassen, nur günstige Ausrüstungsstufen, keine teuren gecrafteten Teile transferieren, Titel-Statboni (account-weit) mitnehmen. Haupteinnahme: **Conquest zahlt ungebundenes Kinah**, das auf den Main wandert; ab ca. 1.600 CP lohnt sich Solo-Conquest auf dem Alt parallel zum Main. | B |
| aion2.online/guides/aion-2-character-progression-guide/ | Skillpunkte reichen nicht für alles – erzwingt Build-Spezialisierung; Testspieler erreichten 45 ohne Cashshop-Käufe (F2P-freundliche Kurve). | C |
| vortexgaming.io/en/postdetail/606901 | **Geteilt:** Kinah und Qunah zwischen eigenen Charakteren; Aufwertungssteine ab +3 auf handelbarer Ausrüstung per Lagerhaus übertragbar. **Nicht geteilt:** angelegte (gebundene) Ausrüstung. Alt-Aufbau in 3 Phasen: Basis (~8 h, Max-Level + Faith-Grind ~1,4 Mio Kinah/h), Mittel (~12 h, Solo-Expedition ~2 Mio Kinah/h), Fortgeschritten (~24 h, 1.600–1.700 Power, Sealed Dungeons, Abyss-Schmuck, verstärktes Lv-55-Unique-Gear). Klassenwahl beim Alt spielt kaum eine Rolle außer Assassin (Solo schwächer) und Kleriker (stark in Gruppeninhalten). | B |
| skycoach.gg/blog/aion-2/articles/aion-2-beginner-guide | **Genus Insight** (Pet-Fortschritt) ist serverweit/account-weit geteilt – muss nicht pro Charakter neu aufgebaut werden. | B |
| mmoexp.com (Titel „84-Run Alt Penalty") | Titel deutet eine Beschränkung bei Mehrfach-Dungeonläufen mit Alts an; Artikeltext beim Abruf nicht auslesbar (nur Metadaten) – **nicht verifiziert**, als offener Punkt markiert. | – (nicht abgerufen) |

## 4. Sonstige Leveling-Tipps (Quelle mmo-codex.com/articles/aion-2-leveling-guide/, B)

- Hauptquest (gelb) ist die klar schnellste XP-Quelle; Rush auf 45 in ca. 7 Stunden
  möglich, entspannt mit Nebeninhalten 1–2 Tage.
- Pro Region abschließen statt aufschieben: Nebenquests, Sealed Dungeons, Stützpunkte
  (Strongholds) direkt in der Region mitnehmen, nicht auf Lv 45 aufsparen.
- Odyle-Energie ab ca. Lv 20 aktivieren, damit sie sich für spätere Dungeon-Belohnungen
  ansammelt.
- Linksklick-Skill (Normalangriff/erster Skill) zuerst leveln – stellt MP wieder her,
  wird am häufigsten genutzt.
- Skill-Resets sind kostenlos → Ausprobieren beim Leveln unproblematisch.
- Ressourcen sparen: Kinah und Aufwertungssteine über +5 hinaus zurückhalten; nur eine
  Waffe auf +5 bringen (Waffenschaden bringt am meisten Klartempo), Gürtel/Amulett nach
  Bedarf mit separaten Ressourcen.
- Daevanion-Punkte beim Leveln zuerst auf „Eck-Slots" (günstigste Knoten), nicht
  gleichmäßig verteilen.
- Bosse der Hauptquest sind lern-, nicht gearbasiert: Attacken-Tells lernen, Dodge-Roll
  als Invinzibilitätsfenster nutzen, Sprint/Dash nach Animationsende timen,
  Kampftempo-/Lauftempo-Tränke einsetzen.
- Elite-Mobs geben spürbar mehr XP als reguläre Mobs.

## 5. Anti-Makro-Politik (Kontext für „möglichst effizient")

aion2.online (Dev-Stream-Recap, Datum vor Chapter 1, B): KR-seitig **Nulltoleranz bei
Maus-Hardware-Makros** (Zero Tolerance), zum Zeitpunkt der Meldung 85.000 Kontosperren
kumuliert, 35.000 davon in einer Woche, mehrere Strafanzeigen angekündigt; zusätzlich
In-Game-Meldefunktion und eine CAPTCHA gegen Sammel-Makros in Entwicklung. Bestätigt
weiterhin: das **In-Game-Skill-Makro** (K → Makro-Tab, siehe `systems.md` Abschnitt 8)
bleibt der einzige empfohlene Weg, mehrere Skills auf eine Taste zu legen – externe
Hardware-Makros sind das Sperr-Risiko, nicht das Ingame-System.

## Offene Punkte

- ~~Federn-Skillpunkt-Änderung zum Global-Release~~ – **gelöst (19.09.2026)**: durch
  zwei direkte Global-Gameplay-Videos bestätigt, siehe Abschnitt 2. Federn speisen
  die Amulett-Progression (Monolith → Amulet Enhancing Scroll), Skillpunkte kommen
  aus Level-Ups + Sealed Dungeons.
- „84-Run Alt Penalty" (mmoexp-Titel): Mechanik unklar, Quelle nicht auslesbar.
- Stigma-Slots Season 1 „4" jetzt durch zwei unabhängige Quellen bestätigt (iggm,
  bereits in `systems.md` durch IGGM referenziert) – Verlässlichkeit von D auf B angehoben.
- Neu offen: Genaue Interaktion von Gear-„+1 Ability Level"-Rolls mit dem
  Daevanion-Cap (Reihenfolge, Reroll-Kosten) nur aus Video-Erklärung bekannt, noch
  nicht durch eine zweite schriftliche Quelle gegengeprüft.

## 6. Neue Quellen: YouTube-Gameplay-Videos (Global-Client)

| Quelle | Aussage | Verl. |
|---|---|---|
| youtube.com/watch?v=n4uaoeGlVb8 – „NoBS Game Guides: Aion 2 Beginners Guide" | Federn → Monolith → Amulet Enhancing Scroll (nicht Skillpunkte); Amulett/Gürtel als permanente Unique-Items; Substance Morph für Amulett-Rarität; Strongholds für Gürtel-Material; Sealed Dungeons = Skillpunkte + Daevanion-Währung, Energy-Limit fürs Bosse-Looten; Daevanion-Cap 14 (4 Bäume × +1); Rest bis 20 über Gear-Rolls; 6 Client-Settings-Empfehlungen; Gear nicht über +1/+2 vor Max-Level aufwerten; Spezialisierungs-Slots bei Lv 8/12/20 (deckt sich mit bisherigem Stand). | A (direkte Client-Gameplay-Aufnahme) |
| youtube.com/watch?v=AZMeJDtfRc4 – „Don't Start Leveling Until You Watch This" | Detaillierte Phasenaufteilung: Lv 1–21 Hauptgrind-Phase (meiste Nebenquests/Federn hier einsammeln), Nebenquests tauchen bei ~Lv 32–33 nochmal auf, Lv 38–45 sehr schnell nur über Hauptquest; Reisen: Flugausdauer für kurze Strecken, Teleport/„Kisks" ab ca. 400–600 m; Hinweis auf Melee- vs. Ranged-Mob-Tagging-Unterschiede. | A (direkte Client-Gameplay-Aufnahme) |
