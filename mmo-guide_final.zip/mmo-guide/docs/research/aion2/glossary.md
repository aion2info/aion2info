# Glossar: Aion 2 (Assassin, Ranger & Gladiator)

Kanonisch ist der **englische Name** (Spieldaten Global-Client). Deutsche Namen sind
Arbeitsübersetzungen (die deutsche Lokalisierung war am 16.09.2026 noch nicht öffentlich)
und müssen nach dem Global-Release mit dem Client abgeglichen werden.

KR-Namen der zwölf aktiven Assassin-Mastery-Skills stammen direkt aus dem
Inven-Skill-Simulator (gesichert). KR-Namen der Passives und Stigmas sind aus
Übersetzungen (Vortex, Inven-Posts) rückübersetzt und können in Schreibweise abweichen.
Der Ranger-Abschnitt weiter unten basiert ausschließlich auf Rückübersetzungen aus
KR-Community-Guides (siehe `ranger-meta.md`, Abschnitt 0) – hier ist die Unsicherheit
größer als beim Assassin-Teil; Einträge ohne KR-Namen wurden nicht belegt gefunden.

## Aktive Mastery-Skills

| EN | KR | KR-Kürzel | DE (vorläufig) | ID |
|---|---|---|---|---|
| Quick Slice → Breaking Slice → Swift Slice | 빠른 베기 (Kette 1/3 → 2/3 → 3/3) | 빠베 | Schneller Schnitt → Brechender Schnitt → Flinker Schnitt | quick-slice, breaking-slice, swift-slice |
| Savage Roar → Savage Back Kick → Savage Smash | 맹수의 포효 | 맹포 | Wildes Gebrüll → Wilder Rücktritt → Wilder Schmetterschlag | savage-roar, savage-back-kick, savage-smash |
| Shadowstrike | 암습 | 암습 | Schattenstoß | shadowstrike |
| Ambush | 기습 | 기습 | Hinterhalt | ambush |
| Heart Gore | 심장 찌르기 | 심찌 | Herzstoß | heart-gore |
| Storm Rampage | 폭풍 난무 | 난무 | Sturmraserei | storm-rampage |
| Whirlwind Slice | 회오리 베기 | 회베 | Wirbelwindschnitt | whirlwind-slice |
| Flash Slice | 섬광 베기 | 섬광 | Blitzschnitt | flash-slice |
| Infiltrate | 침투 | 침투 | Infiltrieren | infiltrate |
| Shadow Fall | 그림자 낙하 | 그낙 | Schattenfall | shadow-fall |
| Insignia Explosion | 문양 폭발 | 문폭 | Insignien-Explosion | insignia-explosion |
| Defiance (→ Storm Slice) | 충격 해제 | – | Trotz (→ Sturmschnitt) | defiance, storm-slice |
| Dark Strike (Kette aus Infiltrate-Spez. 4) | – | – | Dunkler Schlag | dark-strike |
| Dodge | 회피 | – | Ausweichen | dodge |

## Passive Mastery-Skills

| EN | KR | DE (vorläufig) | ID |
|---|---|---|---|
| Heightened Sixth Sense | 육감 극대화 | Geschärfter sechster Sinn | heightened-sixth-sense |
| Exploit Weakness | 빈틈 노리기 | Schwäche ausnutzen | exploit-weakness |
| Apply Poison | 독 바르기 | Gift auftragen | apply-poison |
| Rear Smite | 배후 강타 | Rückenschlag | rear-smite |
| Assault Stance | 강습 자세 | Angriffshaltung | assault-stance |
| Impact Hit | 충격타 | Wuchttreffer | impact-hit |
| Ambush Stance | 기습 자세 | Hinterhaltshaltung | ambush-stance |
| Defense Break | 방어 균열 | Verteidigungsbruch | defense-break |
| Revitalization Contract | 소생의 계약 | Pakt der Wiederbelebung | revitalization-contract |
| Determination | 각오 | Entschlossenheit | determination |

## Stigma-Skills

| EN | KR | KR-Kürzel | DE (vorläufig) | ID |
|---|---|---|---|---|
| Illusive Clone | 환영 분신 | 환분 / 환영 | Trugbild-Klon | illusive-clone |
| Swift Contract | 신속의 계약 | 신속 | Pakt der Schnelligkeit | swift-contract |
| Savage Fang | 맹수의 송곳니 | 송곳니 | Wilder Fangzahn | savage-fang |
| Triniel's Dagger | 트리니엘의 비수 | 비수 | Triniels Dolch | triniels-dagger |
| Evasion Stance | 회피 자세 | 회피 | Ausweichhaltung | evasion-stance |
| Throw Shadowblade (→ Shadowblade Pursuit) | 암흑검 투척 | 암검 | Schattenklinge werfen (→ Schattenklingen-Verfolgung) | throw-shadowblade, shadowblade-pursuit |
| Shadow Walk | 그림자 걷기 | 은신 | Schattengang | shadow-walk |
| Shadowstep | 그림자 걸음 | – | Schattenschritt | shadowstep |
| Spiral Slice | 나선 베기 | – | Spiralschnitt | spiral-slice |
| Smoke Bomb | 연막탄 | – | Rauchbombe | smoke-bomb |
| Aerial Bind (→ Aerial Slaughter) | 공중 속박 | – | Luftfessel (→ Luftschlachtung) | aerial-bind, aerial-slaughter |
| Assault Ambush | 강습 기습 | – | Sturmhinterhalt | assault-ambush |
| Evasion Contract | 회피의 계약 | – | Pakt des Ausweichens | evasion-contract |

Weitere Einträge der Skill-API (Daevanion-/Spezial-Skills, im PvE-Guide nicht zentral):
Frenzied Accord (Rasender Pakt), Surging Bloodlust (Aufwallende Blutgier), Prepare to
Assassinate (Attentat vorbereiten), Apply Poison als Stigma-Variante, Heart Gore/Shadow
Fall „Variante“ (spezialisierte Formen).

Hinweis: Westliche Aggregator-Seiten verwenden eigene Übersetzungen der KR-Namen:
Heart Stab = Heart Gore · Glyph/Rune/Pattern Explosion = Insignia Explosion · Quick
Cut/Slash, Swift Cut = Quick Slice · Predator's Roar / Roar of the Beast / Oath Seal =
Savage Roar · Phantom/Illusion Clone = Illusive Clone · Claw/Fang of the Beast = Savage
Fang · Treniel's Dagger = Triniel's Dagger · Shadow Throw / Dark Sword Throw = Throw
Shadowblade · Stealth Attack = Shadowstrike · Storm Blade/Dance = Storm Rampage.

## Ranger – Aktive Mastery-Skills

| EN | KR | DE (vorläufig) | ID |
|---|---|---|---|
| Snipe | 저격 | Zielschuss | snipe |
| Deadshot | 조준 화살 | Zielpfeil | deadshot |
| Marking Shot | 표적 화살 | Zielmarkierung | marking-shot |
| Drill Dart | 송곳 화살 | Bohrpfeil | drill-dart |
| Arrow Scattershot | 화살 난사 | Pfeilhagel | arrow-scattershot |
| Gale Arrow | 광풍 화살 | Windstoß-Pfeil | gale-arrow |
| Explosion Trap | 폭발의 덫 | Explosionsfalle | explosion-trap |
| Burst Arrow | 파열 화살 | Sprengpfeil | burst-arrow |
| Suppressing Arrow | 제압 | Unterdrückungspfeil | suppressing-arrow |
| Snare Shot | 올가미 화살 | Fesselschuss | snare-shot |
| Tempest Shot | 폭풍 사격 | Sturmschuss | tempest-shot |
| Dodge (klassenübergreifend) | 회피 | Ausweichen | dodge |
| Defiance (klassenübergreifend) | 투지 | Trotz | defiance |

**Korrektur (18.09.2026):** „Rapid Fire" (vormals hier als `rapid-fire` gelistet) und „Shackling Arrow" existieren laut der offiziellen
[questlog.gg-Skilldatenbank](https://questlog.gg/aion-2/en/db/skills/ranger) nicht im echten 35-Skill-Roster des Rangers und wurden entfernt.
„Tempest Arrow" (KR 폭풍의 화살) existiert, aber nicht als eigenständiger Skill, sondern als Kettenfähigkeit, die Snipes Spezialisierung 5
(Skill-Level 16) freischaltet.

## Ranger – Passive Mastery-Skills

| EN | KR | DE (vorläufig) | ID |
|---|---|---|---|
| Vigilant Eye | 경계의 눈 | Wachsames Auge | vigilant-eye |
| Concentrated Fire | 집중 사격 | Konzentriertes Feuer | concentrated-fire |
| Wind Vigor | 바람의 활력 | Windkraft | wind-vigor |
| Focused Eye | 집중의 눈 | Fokussiertes Auge | focused-eye |
| Hunter's Resolve | 사냥꾼의 기백 | Jägerentschlossenheit | hunters-resolve |
| Unyielding Resolve | 불굴의 의지 | Unbeugsamer Wille | unyielding-resolve |
| Rooting Eye | 속박의 눈 | Bindendes Auge | rooting-eye |
| Melee Fire | 근접 화기 | Nahkampf-Feuer | melee-fire |
| Revitalization Contract (klassenübergreifend) | 소생 계약 | Wiederbelebungspakt | revitalization-contract |
| Hunter's Soul | 사냥꾼의 영혼 | Jägerseele | hunters-soul |

## Ranger – Stigma-Skills

| EN | KR | DE (vorläufig) | ID |
|---|---|---|---|
| Bow of Blessing | 축복의 활 | Segen des Bogens | bow-of-blessing |
| Explosive Arrow | 폭발 화살 | Explosivpfeil | explosive-arrow |
| Arrow Storm | 화살 폭풍 | Pfeilsturm | arrow-storm |
| Vaizel's Authority | 바이젤의 권능 | Vaizels Herrschaft | vaizels-authority |
| Griffon Arrow | 그리폰 화살 | Greifenpfeil | griffon-arrow |
| Supporting Fire | 지원 사격 | Unterstützungsfeuer | supporting-fire |
| Ambush Kick | 급습 걷어차기 | Überraschungstritt | ambush-kick |
| Ensnaring Trap | 포박의 덫 | Bindefalle | ensnaring-trap |
| Sealing Arrow | 봉인 화살 | Siegelpfeil | sealing-arrow |
| Illusory Arrow | 환영 화살 | Trugbildpfeil | illusory-arrow |
| Mother Nature's Breath | 대자연의 숨결 | Odem der Natur | mother-natures-breath |
| Stealth | 은신 | Tarnung | stealth |
| Assault Smite (klassenübergreifend) | 강습 강타 | Sturmschlag | assault-smite |

Hinweis: Westliche Aggregator-Seiten verwenden für den Ranger stark abweichende eigene
Übersetzungen, u. a. Griffin/Gryphon's Arrow = Griffon Arrow · Piercing Arrow (vermutlich)
= Drill Dart oder Burst Arrow · Marking Arrow = Marking Shot · Silence Arrow = Sealing
Arrow · Arrow Rain (vermutlich) = Arrow Storm oder Explosion Trap · Blessed Bow = Bow of
Blessing · Byzel/Bayezel/Baize's Authority = Vaizel's Authority. Diese Zuordnungen sind
Vermutungen auf Basis von Rollenbeschreibung und Icon-Abgleich, keine bestätigten Quellen.

## Gladiator – Aktive Mastery-Skills

Koreanische Namen wurden für den Gladiator nicht recherchiert (questlog.gg liefert nur
englische Namen, das Feld `name.kr` wird im Guide-UI nicht angezeigt und ist in
`skills.json` mit `"?"` markiert).

| EN | DE (vorläufig) | ID |
|---|---|---|
| Rending Blow | Reissender Schlag | rending-blow |
| Keen Strike | Scharfer Hieb | keen-strike |
| Crushing Wave | Zermalmende Welle | crushing-wave |
| Ruinous Blow | Verderbenschlag | ruinous-blow |
| Overhead Slam | Überkopf-Schmetterschlag | overhead-slam |
| Leaping Slam | Sprungschlag | leaping-slam |
| Ankle Slice | Fesselschnitt | ankle-slice |
| Defiance (klassenübergreifend) | Trotz | defiance |
| Sword Aura Rampage | Schwertaura-Amoklauf | sword-aura-rampage |
| Mocking Blade | Höhnende Klinge | mocking-blade |
| Aerial Snare | Luftfessel | aerial-snare |
| Rush Strike | Sturmangriff | rush-strike |
| Dodge (klassenübergreifend) | Ausweichen | dodge |

## Gladiator – Passive Mastery-Skills

| EN | DE (vorläufig) | ID |
|---|---|---|
| Survival Stance | Überlebenshaltung | survival-stance |
| Protection Armor | Schutzrüstung | protection-armor |
| Blood Absorption | Blutabsorption | blood-absorption |
| Identify Weakness | Schwäche erkennen | identify-weakness |
| Attack Preparation | Angriffsvorbereitung | attack-preparation |
| Impact Hit | Wuchtiger Treffer | impact-hit |
| Destructive Impulse | Zerstörungsdrang | destructive-impulse |
| Experienced Counterstrike | Erfahrener Gegenschlag | experienced-counterstrike |
| Survival Willpower | Überlebenswille | survival-willpower |
| Murderous Burst | Mörderischer Ausbruch | murderous-burst |

## Gladiator – Stigma-Skills

| EN | DE (vorläufig) | ID |
|---|---|---|
| Blade Toss | Klingenwurf | blade-toss |
| Focused Block | Fokussierter Block | focused-block |
| Armor of Balance | Rüstung des Gleichgewichts | armor-of-balance |
| Wrath Wave | Zorneswelle | wrath-wave |
| Zikel's Blessing | Zikels Segen | zikels-blessing |
| Lifestealing Blade | Lebensraub-Klinge | lifestealing-blade |
| Wave Armor | Wellenrüstung | wave-armor |
| Tenaciousness | Unbeugsamkeit | tenaciousness |
| Rage Burst | Zornesausbruch | rage-burst |
| Lunge Stance | Ausfall-Stellung | lunge-stance |
| Forced Restraint | Erzwungene Fesselung | forced-restraint |
| Assault Strike (klassenübergreifend, bei Ranger „Assault Smite") | Sturmschlag | assault-strike |
| Fracturing Rush | Bruch-Sturm | fracturing-rush |

Hinweis: `Assault Strike` (Gladiator) und `Assault Smite` (Ranger) sind dieselbe
klassenübergreifende Stigma-Fähigkeit (identischer Cooldown, identische Reichweite, gleiches
Icon `ICON_CO_SKILL_003`), unterscheiden sich aber im Status-Effekt (Knockdown beim
Gladiator, Stun beim Ranger) – daher bewusst als zwei Einträge mit eigenem Namen geführt,
nicht zusammengelegt. Ebenso ist `Defiance` bei beiden Klassen identisch (`ICON_CO_SKILL_002`).

## Spielbegriffe

| EN | KR | Kürzel | Bedeutung |
|---|---|---|---|
| Mastery Skill / Mastery Points | 마스터리 스킬 / 마스터리 포인트 | – | Klassenskills, die man per Level lernt; Skillpunkte zum Leveln bis Stufe 10 |
| Specialization | 특화 | 특화 | 5 Optionen pro Mastery-Skill, 3 Slots (Skill-Lv 8 / 12 / 20) |
| Stigma / Stigma Shard | 스티그마 / 스티그마 샤드 | 스티 | Zusatzskills in eigenen Slots; Leveln mit Shards |
| Insignia | 문양 | 문양 | Stapelbare Markierung am Ziel (max. 5), verstärkt Insignia Explosion |
| Stagger / Stagger Gauge | 그로기 / 경직 게이지 | 그로기 | Boss-Taumelzustand; Storm Rampage nur dann nutzbar |
| Back Attack | 백어택 / 배후 공격 | 백어택 | Angriff von hinten; Rear Smite, Ambush, Triniel's Dagger profitieren |
| Combat Speed | 전투 속도 | 전속 | Angriffs-/Animationsgeschwindigkeit |
| Cooldown Reduction | 재시전 시간 감소 | 쿨감 | Abklingzeit-Reduktion |
| Multi-Hit | 다단 히트 | 다단 | Zusatztreffer-Chance |
| Lifesteal / HP absorb | 생명력 흡수 | 피흡 | HP-Absorption |
| Normal attack | 평타 | 평타 | Normalangriff (linke Maustaste, bei Assassin die Quick-Slice-Kette) |
| Skill Macro (in-game) | 스킬 매크로 | 인매 | Ingame-Makro (K → Makro-Tab) |
| Quickslot line | 라인 | 라인 | Bis zu 4 Skills pro Slot, Priorität 0→1→2→3 |
| Skill queue | 스킬 예약 | 예약 | Option im Makro/Client, Skill wird vorgemerkt statt verworfen |
| Left / right mouse | 좌클릭 / 우클릭 | 좌 / 우 | LMB / RMB |
| Daevanion | 데바니온 | 데바 | Knotenbretter für Stats und Skill-Level über 10 |
| Arcana | 아르카나 | – | Karten-System, hebt Skill-Level (Scroll/Parchment aktiv, Chalice/Grail passiv) |
| Soul Imprint | 소울 임프린트 / 영혼 각인 | – | Ausrüstungsoption, gibt Skill-Level |
| Stone of Wisdom | 지혜의 돌 | – | Gegenstand, gibt zusätzliche Skillpunkte |
| Abyss Points | 어비스 포인트 | 어포 | PvP-Währung, u. a. für Stigma-Shards |
