# Gladiator PvE – Meta (Stand 18.09.2026)

Konsolidiert aus der offiziellen questlog.gg-Skilldatenbank (Tooltip-Text, Cooldowns,
Spezialisierungen), aion2.app (Freischalt-Level) sowie aion2hub.com, aion2wiki.com und dem
vom Nutzer verlinkten YouTube-Video „AION 2 Gladiator Macro Guide" (Kanal „Sen") für
Makro-/Rotationskontext. Anders als bei der ursprünglichen Ranger-Recherche dieses Repos lag
für den Gladiator von Anfang an die vollständige questlog.gg-API vor – dieser Guide enthält
daher keine „Korrektur"-Geschichte wie der Ranger-Guide, sondern ist von Beginn an auf dem
A-Tier-Datenstand.

## 0. Warum „Bruiser/Off-Tank", nicht „Haupttank"

Das ist die wichtigste Einordnungsfrage für diesen Guide, weil sie die gesamte
Rotations-Erzählung bestimmt (Aggro-/Mitigations-fokussiert vs. schadensfokussiert). Drei
unabhängige Belege stützen die Einordnung als Bruiser mit Off-Tank-Werkzeug:

1. **aion2hub.com** beschreibt den Gladiator als „aggressive, in-your-face bruiser that
   closes distance and unleashes wide arcing greatsword swings to hit several foes at once,
   healing off the damage it deals to outlast opponents" – Fokus auf Lebensraub-Sustain,
   nicht auf Shield-/Kontroll-Mechaniken eines klassischen MMO-Tanks.
2. **aion2wiki.com** nennt „high attack and defense, with a primary melee-damage role and
   enough health and protection to act as a secondary tank" – explizit „secondary", nicht
   „primary" oder „main".
3. **Die Skilldaten selbst** referenzieren zweimal wörtlich die Templer-Klasse als
   Vergleichspunkt: `Rage Burst`s Wounded-Debuff „does not stack with the Shrink effect from
   the Templar skill [Taunt]", `Experienced Counterstrike`s Party-Schadensbonus „does not
   stack with Templar's [Fury] effect". Beide Formulierungen setzen voraus, dass der Templer
   die Klasse mit dem dedizierten Taunt-/Tank-Kit ist – der Gladiator wird an beiden Stellen
   als eigenständiges, andersartiges Kit behandelt, das zufällig ähnliche Effekt-Kategorien
   berührt (Shrink/Wounded, Fury/Damage-Boost-on-Block).

Der Gladiator hat trotzdem echte Off-Tank-Bausteine: Enmity-Erzeugung auf beiden 0-CD-
Basisskills plus auf Overhead Slam, ein garantiertes Parry/Block-Werkzeug (Focused Block)
und einen Panik-Knopf (Tenaciousness). Das reicht für kurze Einspring-Momente oder Solo-/
Duo-Content, ersetzt aber laut den obigen Quellen keinen dedizierten Haupttank in
Gruppen-Endgame-Content.

## 1. Kern-Skills und Ziel-Level

| Skill | Ziel-Level (Endgame) | Warum |
|---|---|---|
| Sword Aura Rampage | 20 | Kein fester CD, aber nur gegen gestaggerte Ziele – der wichtigste kostenlose Payoff-Skill, direkt verstärkt durch Destructive Impulse |
| Keen Strike | 20 | Kein fester CD, zweiter Grundangriff, MP-positiv; Spez. 5 schaltet Reckless-Strike-Kette frei |
| Overhead Slam | 20 | 5 s CD, nur gegen Knockdown-Ziele, aber sehr kurze Abklingzeit macht ihn zum Rotationskern, sobald Knockdown steht |
| Mocking Blade | 16 | Zentraler Combo-Starter (setzt Knockdown), schaltet damit Overhead Slam und Aerial Snare frei |
| Ruinous Blow | 16 | Sprung-Burst mit Selbst-Buff Prepare for Battle (+20 % PvE-Schaden, +100 Krit, +15 % Status-Chance) – zentraler Opener |
| Ankle Slice | 16 | Fester Rotationsbaustein mit Root-Chance, kurzer CD (10 s) |
| Rending Blow | 10 | Kein fester CD, Enmity-Basisskill |
| Crushing Wave | 10 | Flächenschaden um den Gladiator, 20 s CD |
| Aerial Snare | 10 | Zweiter Knockdown-Payoff, seltener nutzbar (45 s CD) |
| Leaping Slam / Rush Strike | 10 (optional) | Mobilität mit Nebeneffekten, niedrigere Priorität als reine Schadens-/Combo-Skills |

## 2. Knockdown- und Stagger-Ketten (zentrale Kit-Mechanik)

- **Knockdown-Kette:** `Mocking Blade` (20 s CD) verursacht Knockdown für 3 s. Nur während
  dieses Fensters sind `Overhead Slam` (5 s CD, zusätzliche Enmity) und `Aerial Snare` (45 s
  CD, zusätzlich Airborne) überhaupt nutzbar. Alternative Knockdown-Quellen: `Wrath Wave`
  (Stigma, 50 % Chance) und `Rage Burst` (Stigma, versetzt das Ziel unabhängig von Mocking
  Blade für 10 s in den für Overhead Slam nutzbaren Zustand).
- **Stagger-Kette:** Fast jeder Schadens-Skill lädt die Stagger Gauge auf (Wrath Wave 50,
  Ruinous Blow 25, Mocking Blade 15, mehrere Skills 20, Ankle Slice/Leaping Slam/Rush Strike
  je 10, Rending Blow/Keen Strike/Overhead Slam/Crushing Wave je 2–5). Ist sie voll, wird
  `Sword Aura Rampage` (0 s CD) nutzbar – ein kostenloser Bonus-Treffer, den die Passive
  `Destructive Impulse` zusätzlich verstärkt (Bonus-Schaden gegen gestaggerte/Impact-Ziele).
- Beide Ketten sind strukturell identisch zum Ranger-Guide dieses Repos (dort: Slow →
  Burst Arrow, Stagger → Arrow Scattershot) – das Grundprinzip „Setup-Skill schaltet
  Payoff-Skill frei" zieht sich durch mehrere Aion-2-Klassen.

## 3. Stigma-Prioritäten

**PvE-Kernset (vier Slots, Season 1):**
1. **Focused Block** – 20 s CD, garantiertes Parry + 100 % Block-Schadensreduktion. Einziges
   Stigma mit aktiver Mitigation auf Abruf; praktisch Pflicht, sobald der Gladiator
   zeitweise Aggro trägt.
2. **Tenaciousness** – 150 s CD, 3 s volle Unverwundbarkeit. Panik-Knopf für angekündigte
   Ein-Schlag-Mechaniken; blockt laut eigenem Tooltip „bestimmte besonders starke Angriffe"
   nicht.
3. **Wrath Wave** – 60 s CD, höchster Stagger-Wert im Kit (50) plus 50 % Knockdown-Chance;
   Doppelfunktion als AoE-Hit und Knockdown-Ersatzquelle.
4. **Lifestealing Blade** – 90 s CD, Eigen-Lebensraub plus Predation-Buff für die gesamte
   Gruppe (20 s) – bestes Sustain-/Support-Stigma.

**Flex-Alternativen für Slot 3/4:** `Rage Burst` (Debuff plus alternative
Overhead-Slam-Freischaltung, wenn die Knockdown-Kette öfter reißt), `Zikel's Blessing`
(reiner Eigen-Schadensbuff, wenn Sustain nicht limitierend ist), `Blade Toss` (Verteidigungs-
Debuff auf 20 m Reichweite, situativ als Opener-Ergänzung auf Bossen).

Diese Priorisierung ist eine eigene Ableitung aus den Skill-Mechaniken (Cooldown-Länge,
Rollen-Framing, Synergie mit der Knockdown-/Stagger-Kette) – anders als beim Assassin/Ranger
lag zum Recherchezeitpunkt keine dedizierte KR-Community-Stigma-Rangliste für den Gladiator
vor, die diese Reihenfolge unabhängig bestätigt.

## 4. Rotation / Makro

- **Kern-Loop:** Rending Blow und Keen Strike (beide 0 s CD, beide Enmity) als Lückenfüller
  zwischen den Cooldown-Skills, kein Animation-Cancel-Mechanismus zwischen beiden (anders als
  die ursprünglich fehlerhafte Ranger-Snipe/Rapid-Fire-Annahme – hier gibt es keinen
  vergleichbaren Fehler zu korrigieren, da von Anfang an mit A-Tier-Daten gearbeitet wurde).
- **Video-Kontext:** Das vom Nutzer verlinkte YouTube-Video („AION 2 Gladiator Macro Guide",
  Kanal Sen) vergleicht laut Videobeschreibung und Kapitelmarken den DPS-Unterschied
  zwischen manuellem Spiel und Makro-Nutzung für die Gladiator-Rotation. Ein automatischer
  Transkript-Abruf lieferte keine Daten (leere Antwort der `timedtext`-API, vermutlich
  abgelaufene Signatur); ausgewertet wurden Titel, vollständige Beschreibung und
  Kapitelstruktur (Intro/Fähigkeiten-Erklärung → DPS-Test ohne Makro → DPS-Test mit Makro →
  Makro-Setup). Das bestätigt grundsätzlich das im Guide verwendete Slot-Linien-Prinzip
  (bedingte Skills oben, Dauerfüller unten), liefert aber keine zitierfähigen Konkret-Werte
  (Delay-ms, genaue Skill-Reihenfolge im Makro) – diese im Guide verwendeten Werte sind daher
  als eigene, aus dem Kit abgeleitete Empfehlung markiert, nicht als Video-Zitat.

## 5. Stats

- **Accuracy** vor reinen Schadenswerten: Die komplette Knockdown-/Root-Combo-Kette (Mocking
  Blade, Ankle Slice, Wrath Wave) hängt an Trefferchancen – kein konkreter Richtwert aus
  Community-Quellen gefunden (anders als der Ranger-Richtwert 1350–1400 aus KR-Guides),
  daher nur als Prioritäts-Rang ohne Zahl übernommen.
- **Block** als Gladiator-spezifischer Stat: aktiviert sowohl `Protection Armor`
  (Heilung bei Block) als auch `Experienced Counterstrike` (Party-Schadensbonus bei Block) –
  ein Stat, der bei reinen DPS-Klassen (Assassin, Ranger) keine vergleichbare Doppelrolle
  hat.
- **Kampfgeschwindigkeits-Obergrenze:** keine Gladiator-spezifische Zahl gefunden (anders als
  der Ranger-Wert ~88,1 % aus dem Vortex-Guide); im Trainingsraum selbst testen.

## 6. Offene Punkte für die nächste Aktualisierung

- Vollständiges Transkript des verlinkten YouTube-Makro-Guides auswerten, sobald
  automatisierter Zugriff zuverlässig funktioniert (aktuell nur Titel/Beschreibung/Kapitel).
- Zweites, per WebSearch gefundenes, aber nicht ausgewertetes Video prüfen:
  „AION 2 Gladiator PVE Build for Skills & Stigmas | Beginners Guide"
  (`https://www.youtube.com/watch?v=EAjD1naPlU0`).
- Dedizierte KR- oder internationale Community-Stigma-Prioritätsliste für den Gladiator
  suchen, um die in Abschnitt 3 selbst abgeleitete Reihenfolge unabhängig zu bestätigen oder
  zu korrigieren.
- Exakte Namen und Werte der über Spezialisierungen freigeschalteten Kettenfähigkeiten
  (Reckless Strike, Upward Strike, Ankle Smash, Wrath Burst, Forced Fall, Destructive Rush,
  Unsheathing Rush) recherchieren – in der questlog.gg-API nicht als eigene Skill-Einträge
  gelistet, nur als Text in der jeweiligen Spezialisierungs-Beschreibung des Basis-Skills.
  Gleiches gilt für Reckless Strike als Keen-Strike-Kettenfähigkeit.
- Koreanische Skillnamen recherchieren (aktuell komplett unbekannt, `name.kr` = `"?"` in
  `skills.json`), sobald eine belastbare KR-Quelle für den Gladiator vorliegt.
- Konkrete Accuracy-/Kampfgeschwindigkeits-Richtwerte aus Community-Quellen nachtragen,
  sobald verfügbar (siehe Abschnitt 5).
