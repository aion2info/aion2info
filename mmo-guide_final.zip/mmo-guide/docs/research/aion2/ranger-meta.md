# Ranger PvE – KR-Meta (Stand 18.09.2026)

Konsolidiert aus 아이온2 인벤 (Inven, Ranger-Board „궁성"), game.savetip.co.kr,
Vortex Gaming (Aug/Sept 2026) und aion2hub.com. Skillnamen englisch (aion2.app-Namen),
koreanische Originalnamen in Klammern zur Rückverfolgung.

**Wichtiger Unterschied zur Assassin-Recherche:** Für den Assassin lag eine vollständige
API-Datenbank mit Tooltip-Text und allen fünf Spezialisierungs-Optionen je Skill vor. Für
den Ranger stand zum Recherchezeitpunkt nur eine Skill-**Übersicht** (Name, Level, CD, MP,
Icon-Code) zur Verfügung; Wortlaute von Beschreibungen und Spezialisierungen unten sind aus
Community-Fragmenten abgeleitet, nicht wörtlich zitiert. Wo eine Zuordnung unsicher ist,
steht das explizit dabei.

## 0. Namensabgleich Koreanisch → Englisch

Deutsche Aggregator-/KI-Übersetzungen der KR-Guides verwenden uneinheitliche englische
Namen. Zuordnung für diesen Guide (Basis: aion2.app-Namen):

| Koreanisch | Guide-Fund (Übersetzung) | Verwendeter Name (aion2.app) |
|---|---|---|
| 저격 | Snipe / Aim | **Snipe** |
| 속사 | Rapid Fire / Rapid Shot | **Rapid Fire** |
| 조준 화살 | Aimed Arrow / Aim | **Deadshot** |
| 표적 화살 | Target Arrow / Mark Arrow | **Marking Shot** |
| 송곳 화살 | Spike Arrow / Spike Shot | **Drill Dart** |
| 화살 난사 | Arrow Barrage | **Arrow Scattershot** |
| 광풍 화살 | Gale Arrow / Gust | **Gale Arrow** |
| 폭발의 덫 | Explosive Trap | **Explosion Trap** |
| 폭발 화살 | Exploding Arrow | **Explosive Arrow** (Stigma) |
| 화살 폭풍 | Arrow Storm | **Arrow Storm** (Stigma) |
| 축복의 활 | Blessed Bow | **Bow of Blessing** (Stigma) |
| 바이젤의 권능 | Bijel's/Baize's/Bayezel's Authority | **Vaizel's Authority** (Stigma) |
| 그리폰 화살 | Griffin/Gryphon's Arrow | **Griffon Arrow** (Stigma) |
| 지원 사격 | Supporting Fire | **Supporting Fire** (Stigma) |
| 족쇄 화살 | Shackle Arrow | **Shackling Arrow** |
| 올가미 화살 | Snare Arrow | **Snare Shot** |
| 속박의 눈 | Eye of Restraint/Binding | **Rooting Eye** (passiv) |

Quellen für diese Zuordnung: Icon-Code-Abgleich mit der aion2.app-Übersicht (gleiche
Freischalt-Level, gleiche geteilte Icons wie `ICON_CO_SKILL_002` = Defiance bei beiden
Klassen) plus inhaltliche Übereinstimmung mit den Inven-/savetip-Guides.

## 1. Kern-Skills und Ziel-Level

| Skill | Ziel-Level (Endgame) | Warum |
|---|---|---|
| Rapid Fire | 20, höchste Priorität | Kein fester CD, laut Inven-Guide höchster kumulierter Schadensanteil im Kit |
| Snipe | 20 | Kein fester CD, zweiter Grundangriff; Spez. 5 gilt als „Pflicht-Pick" |
| Deadshot | 20 | Härtester Einzeltreffer, voll aufgeladen aus Distanz am stärksten |
| Marking Shot | 16 | Verteidigungs-Debuff, Grundlage für den restlichen Schaden am Ziel |
| Arrow Scattershot | 16 | Stagger-Aufbau; Spez. 5 (−1 s CD) als fixe Empfehlung genannt |
| Drill Dart | 8–10 | Kurzer CD (5 s), Blutungs-DoT, Lückenfüller |
| Burst Arrow / Suppressing Arrow | 8–10 | Sekundäre Burst-/Debuff-Skills |
| Gale Arrow | situativ, evtl. 20 | Community-Konsens (Stand Recherche): meist aus der Rotation genommen, weil der erzwungene Ladevorgang den Animation-Cancel-Rhythmus bricht; erhöht laut Vortex aber die Kampfgeschwindigkeits-Obergrenze |

Inven-Guide („궁성 가이드"): „Snipe → Ziel 20 (Lv-12-Sockets: Multi-Hit, Aimed Arrow;
Lv-16: Aimed Arrow, Gale Arrow; Lv-20: 5. Socket ist GOAT). Rapid Fire → Ziel 20, höchste
Priorität für kumulativen DPS (Lv-12: Skill-Crit-Erhöhung, weniger-Ziele-Bonus; Lv-16:
Maximalschaden, +20 % Skill-Speed; Lv-20: Crit-Erhöhung, Schadenserhöhung, +20 %
Skill-Speed). Gale Arrow: nicht benutzen, langer Vorlauf bricht den Cancel-Rhythmus,
niedrigerer DPS als reines Wechselklicken ohne Lv-20-Spezialisierung."

## 2. Spezialisierungs-Hinweise (unsicherer als beim Assassin)

Nur für Skills mit belastbaren Fragmenten aus den KR-Guides; alle anderen Spezialisierungs-
Texte in `skills.json` sind thematisch plausibel rekonstruiert, nicht quellenbelegt.

| Skill | Fragment aus KR-Guide | Eigene Einordnung in `skills.json` |
|---|---|---|
| Snipe | Lv 12: Multi-Hit, Aimed Arrow-Synergie · Lv 16: Aimed-Arrow-Synergie, Gale-Arrow-Synergie · Lv 20: 5. Socket „GOAT" | Optionen 4 (−CD Rapid Fire), 5 (+Schaden aus dem Rücken) sinngemäß übernommen |
| Rapid Fire | Lv 12: Skill-Crit-Erhöhung, Schaden bei weniger Zielen · Lv 16: Maximalschaden, +20 % Skill-Speed · Lv 20: Crit-Erhöhung, Schadenserhöhung, +20 % Skill-Speed | Optionen 2–5 sinngemäß übernommen |
| Marking Shot | „Falls CD via [Fantasy]-Stats auf ~7 s sinkt: +2 s Wirkdauer-Option; Lv-16-Invest sonst nicht empfohlen" | Option 5 als bedingte Empfehlung übernommen |
| Arrow Scattershot | „5. Socket: −1 s CD (fixe Empfehlung)" | Option 5 fix empfohlen |
| Drill Dart | „Lebensraub-Socket vor Multi-Hit priorisieren, wichtig für harte Dungeons" | Option 2 (Lebensraub) als Solo-Alternative zu Option 3 (Multi-Hit) |

## 3. Stigma-Prioritäten (zwei KR-Momentaufnahmen)

**Inven-Guide (aktuellere Quelle der Recherche):**
1. **Bow of Blessing** – Ziel-Level 15, „nicht ersetzbar", Party-Krit-Schaden bei
   100/200 eigenen Krit-Treffern.
2. **Explosive Arrow** – Level 5 Pflicht-Breakpoint (−15 s CD), Level 10 als ineffizient
   beschrieben.
3. **Arrow Storm** – schon auf niedrigem Level einsatzbereit, hoher Stagger-Wert plus
   Hard-CC-Potenzial gegen Trash.
4. **Vaizel's Authority** (optional) – langer Nachlauf; bei hoher eigener Angriffskraft
   gegen Griffon Arrow oder Ambush Kick tauschbar.

**Vortex-Guide (Patch-Analyse):** „Vaizel's Authority, Bow of Blessing und Griffon Arrow
je auf Stigma-Level 20, Supporting Fire reicht auf Level 15; die Perfect-Option ist für die
Schadensdecke entscheidend, weil Gegner kaum Perfect-Resistenz haben."

**Andere KR-Quelle (savetip.co.kr, vermutlich anderer Patch-Stand):** „Bayezel [Vaizel's
Authority] > Revitalize > Griffin [Arrow] > Support[ing Fire] > Explos[ive Arrow]" – ohne
konkrete Level-Angaben („변화무쌍/스펙별 효율 계속 바뀜" – Effizienz ändert sich mit Patch/Gear).

**Ableitung für diesen Guide:** Bow of Blessing, Explosive Arrow und Arrow Storm als
Kern-Set (in allen Quellen vertreten), vierter Slot flexibel zwischen Vaizel's Authority
(Standard), Griffon Arrow (reiner Schaden bei hoher Angriffskraft) und Supporting Fire
(Gruppeninhalte).

## 4. Rotation / Makro

- **Kern-Loop:** Snipe (평타 links) und Rapid Fire (속사 rechts) ohne festen Cooldown,
  Schaden entsteht über Animation-Cancel zwischen beiden.
- **Zwei widersprüchliche Empfehlungen zur Eingabe:**
  - Vortex-Makro-Guide (Aug 2026): Rapid Fire im Makro auf Linksklick halten, Snipe auf
    Maus-Seitentaste, Rechtsklick für Burst-Skill bei Bedarf spammen. Kombiniert mit dem
    Fakt, dass Gale Arrow inzwischen einen Kampfgeschwindigkeits-Effekt hat, der die
    Obergrenze auf 88,1 % anhebt; Testreihe zeigt Steigerung von 2,43 auf 2,69 (13–14 s
    Messfenster) nach Umstellung.
  - Inven-Guide (neuer): explizit **gegen** das gehaltene Makro für den Kern-Loop –
    direktes Wechselklicken mit **Skill-Queue aus** erzeugt saubereren Animation-Cancel
    und mehr kumulierten Schaden; Empfehlung, Maustasten auf die Tastatur zu legen
    (Handgelenk-Schonung).
- Dieser Guide zeigt beide Varianten (Reiter Makros, „Makro 1" vs. „Variante A"), weil sich
  die Quellen widersprechen und beide plausibel wirken – die neuere Inven-Quelle wird als
  wahrscheinlich aktuellerer Stand priorisiert, ohne die Makro-Variante zu verschweigen.

## 5. Stats

- **Accuracy/Hit** vor reinen Schadenswerten: Richtwert 1 350–1 400 für „Parry"-Vermeidung
  in schweren Dungeons (Inven-Guide, im Kontext einer namentlich genannten Dungeon-Instanz,
  hier bewusst nicht übernommen, da Instanznamen sich bis Global ändern können).
- **Perfect-Stat** (KR: 필중, sinngemäß „Passgenauigkeit"): laut Vortex-Guide fast so
  effizient wie Critical Hit, weil Monster kaum Perfect-Resistenz haben, und wirkt
  zusätzlich auf den Waffenschaden.
- **Kampfgeschwindigkeits-Obergrenze:** ~88,1 % (Vortex-Guide); darüber hinaus laut
  Community-Berichten MP-Probleme und verschluckte Rapid-Fire-Eingaben.

## 6. Offene Punkte für die nächste Aktualisierung

- Vollständige Tooltip-Texte/Spezialisierungslisten aus der API nachtragen, sobald verfügbar
  (aktuell nur Übersicht, siehe oben).
- Freischalt-Level für die zehn „special"-Skills (Afterimage, Arrow of Space-time, Dust
  Arrow, Eye of Rapid Burst, Guerilla Strike, „Hunter's Resolve (aktiv)", Impact Kick,
  Lightning Arrow, Spiral Arrow, Tempest Arrow) klären.
- Klären, ob „Hunter's Resolve" als aktiver UND passiver Skill existiert oder ob das eine
  Fehlzuordnung der Ausgangsquelle ist.
- Widerspruch zwischen den beiden Stigma-Prioritätslisten (Inven vs. savetip.co.kr) anhand
  eines aktuelleren Patch-Standes auflösen.
- Icons herunterladen (`bash scripts/fetch-icons.sh ranger`), sobald ein Rechner mit
  Zugriff auf `cdn.aion2pb.com` verfügbar ist.
