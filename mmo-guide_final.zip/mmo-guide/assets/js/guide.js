/* mmo-guide – Reiter, Skill-Chips, Tooltips, generierte Tabellen.
   Erwartet window.GUIDE_DATA (gesetzt in der Seite) mit { data, iconBase }. */
(function () {
  "use strict";
  const cfg = window.GUIDE_DATA || {};
  const DATA = cfg.data || { skills: [], meta: {} };
  const ICON_BASE = cfg.iconBase || "";
  const byId = new Map(DATA.skills.map((s) => [s.id, s]));
  const TYPE_LABEL = (DATA.meta && DATA.meta.types) || {};
  const ROLE_LABEL = (DATA.meta && DATA.meta.roles) || {};

  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const iconImg = (s, cls) => s && s.icon
    ? `<img src="${ICON_BASE}${esc(s.icon)}" alt="" loading="lazy"${cls ? ` class="${cls}"` : ""}>`
    : `<span class="ph">${esc((s && s.name.en || "?").split(" ").map((w) => w[0]).join("").slice(0, 3))}</span>`;
  const nameOf = (s) => s.name.en;

  /* ---------- Skill-Chips ---------- */
  function renderChip(el) {
    const id = el.dataset.skill;
    const s = byId.get(id);
    const size = el.dataset.size || "";
    if (!s) {
      console.warn("[guide] Unbekannte Skill-ID:", id);
      el.outerHTML = `<span class="skill-chip missing" title="unbekannt: ${esc(id)}">${esc(id)}</span>`;
      return;
    }
    const label = el.hasAttribute("data-noname") ? "" : `<span>${esc(el.dataset.label || nameOf(s))}</span>`;
    el.outerHTML = `<a class="skill-chip t-${esc(s.type)}" data-tip="${esc(id)}" data-size="${esc(size)}" href="#skills@skill-${esc(id)}" title="${esc(nameOf(s))}">${iconImg(s)}${label}</a>`;
  }

  /* ---------- Tooltip ---------- */
  let tip;
  function ensureTip() {
    if (tip) return tip;
    tip = document.createElement("div");
    tip.className = "tooltip";
    document.body.appendChild(tip);
    return tip;
  }
  function tipHtml(s) {
    const stats = [
      s.unlock_level ? `Freischaltung Lv ${s.unlock_level}` : "",
      s.cooldown ? `CD ${s.cooldown}` : "",
      s.mp ? `MP ${s.mp}` : "",
      s.range ? `Reichweite ${s.range}` : "",
    ].filter(Boolean).join(" · ");
    let specs = "";
    if (s.specs && s.specs.length) {
      const rec = new Set();
      const rs = s.pve && s.pve.recommended_specs;
      if (rs) Object.values(rs).forEach((arr) => arr.forEach((n) => rec.add(n)));
      const isStigma = s.type === "stigma";
      specs = `<ol>${s.specs.map((sp) => `<li class="${!isStigma && rec.has(sp.n) ? "rec" : ""}"><span class="lv">${isStigma ? "Lv" : "ab Lv"} ${sp.unlock}</span> ${esc(sp.text)}</li>`).join("")}</ol>`;
    }
    const pve = s.pve ? `<div class="pve"><b>PvE:</b> ${esc(ROLE_LABEL[s.pve.role] || s.pve.role)}${s.pve.tier ? ` · Tier ${esc(s.pve.tier)}` : ""}${s.pve.target_level ? ` · Ziel Lv ${esc(s.pve.target_level.leveling)} → ${esc(s.pve.target_level.endgame)}` : ""}<br>${esc(s.pve.notes || "")}</div>` : "";
    return `<header>${iconImg(s)}<div><b>${esc(nameOf(s))}</b><small>${esc(TYPE_LABEL[s.type] || s.type)}${s.name.de_provisional ? ` · dt. vorläufig: ${esc(s.name.de_provisional)}` : ""}</small></div></header>
      ${stats ? `<div class="stats">${esc(stats)}</div>` : ""}
      <div class="desc">${esc(s.description)}</div>${specs}${pve}`;
  }
  function showTip(e) {
    const a = e.target.closest("[data-tip]");
    if (!a) return;
    const s = byId.get(a.dataset.tip);
    if (!s) return;
    const t = ensureTip();
    t.innerHTML = tipHtml(s);
    t.classList.add("show");
    moveTip(e);
  }
  function moveTip(e) {
    if (!tip || !tip.classList.contains("show")) return;
    const pad = 14, w = tip.offsetWidth, h = tip.offsetHeight;
    let x = e.clientX + pad, y = e.clientY + pad;
    if (x + w > window.innerWidth - 8) x = e.clientX - w - pad;
    if (y + h > window.innerHeight - 8) y = Math.max(8, e.clientY - h - pad);
    tip.style.left = x + "px"; tip.style.top = y + "px";
  }
  function hideTip() { if (tip) tip.classList.remove("show"); }

  /* ---------- Generierte Tabellen ---------- */
  const specPicks = (s, lv) => {
    const rs = s.pve && s.pve.recommended_specs;
    if (!rs || !rs[lv]) return "–";
    return rs[lv].map((n) => `<span class="spec-pick rec">${n}</span>`).join("");
  };
  function skillTable(el) {
    const types = (el.dataset.types || "active").split(",");
    const skills = DATA.skills.filter((s) => types.includes(s.type));
    const isPassive = types.includes("passive");
    const isStigma = types.includes("stigma");
    const sortKey = (s) => (isStigma || isPassive) && s.pve && s.pve.priority ? s.pve.priority : (s.unlock_level || 999);
    skills.sort((a, b) => sortKey(a) - sortKey(b));
    let head = `<tr><th>Skill</th><th class="num">Lv</th>${isPassive ? "" : "<th>CD / MP</th>"}<th>Effekt</th><th>PvE-Rolle</th>${isPassive ? '<th class="num">Prio</th>' : ""}<th class="num">Ziel-Lv</th>${!isPassive && !isStigma ? '<th>Spez. bei 8 / 12 / 16 / 20</th>' : ""}</tr>`;
    const rows = skills.map((s) => {
      const tl = s.pve && s.pve.target_level ? `${s.pve.target_level.leveling} → ${s.pve.target_level.endgame}` : "–";
      const cd = [s.cooldown ? `CD ${s.cooldown}` : "", s.mp ? `MP ${s.mp}` : ""].filter(Boolean).join("<br>") || "–";
      const role = s.pve ? `<span class="badge role">${esc(ROLE_LABEL[s.pve.role] || s.pve.role)}</span> ${s.pve.tier ? `<span class="badge ${esc(s.pve.tier)}">${esc(s.pve.tier)}</span>` : ""}` : "";
      const specCol = !isPassive && !isStigma ? `<td>${["8", "12", "16", "20"].map((lv) => `<span class="muted" style="font-size:.75rem">${lv}:</span> ${specPicks(s, lv)}`).join(" &nbsp; ")}</td>` : "";
      const specList = s.specs && s.specs.length ? `<ol style="margin:.4rem 0 0;padding-left:1.1rem;font-size:.85rem;color:var(--muted)">${s.specs.map((sp) => `<li><span class="muted">${isStigma ? "Lv" : "ab"} ${sp.unlock}:</span> ${esc(sp.text)}</li>`).join("")}</ol>` : "";
      return `<tr id="skill-${esc(s.id)}"><td><a class="skill-chip t-${esc(s.type)}" data-tip="${esc(s.id)}" data-size="lg" href="#skills@skill-${esc(s.id)}">${iconImg(s)}<span>${esc(nameOf(s))}</span></a>${s.name.de_provisional ? `<div class="muted" style="font-size:.78rem">dt. vorläufig: ${esc(s.name.de_provisional)}</div>` : ""}</td>
        <td class="num">${s.unlock_level ?? "–"}</td>${isPassive ? "" : `<td style="white-space:nowrap">${cd}</td>`}
        <td class="desc">${esc(s.description)}${specList}${s.pve && s.pve.notes ? `<div style="margin-top:.4rem;color:#cfd2df"><b>Guide:</b> ${esc(s.pve.notes)}${s.pve.alt_specs ? ` <i class="muted">${esc(s.pve.alt_specs)}</i>` : ""}</div>` : ""}</td>
        <td>${role}</td>${isPassive ? `<td class="num">${s.pve && s.pve.priority ? s.pve.priority : "–"}</td>` : ""}<td class="num">${tl}</td>${specCol}</tr>`;
    });
    el.innerHTML = `<div class="table-wrap"><table><thead>${head}</thead><tbody>${rows.join("")}</tbody></table></div>`;
  }

  /* ---------- Quickbar-Mockup ---------- */
  function quickbar(el) {
    el.querySelectorAll(".slot[data-skills]").forEach((slot) => {
      const ids = slot.dataset.skills.split(",").map((x) => x.trim()).filter(Boolean);
      const line = document.createElement("div");
      line.className = "line";
      line.innerHTML = ids.map((id, i) => {
        const s = byId.get(id);
        if (!s) { console.warn("[guide] Quickbar: unbekannte ID", id); return ""; }
        return `<div class="entry"><span class="prio">${i}</span><a data-tip="${esc(id)}" href="#skills@skill-${esc(id)}">${iconImg(s)}</a><span class="n t-${esc(s.type)}">${esc(nameOf(s))}</span></div>`;
      }).join("");
      const hint = slot.querySelector(".hint");
      slot.insertBefore(line, hint || null);
    });
  }

  /* ---------- Schritt-Karten ---------- */
  function steps(el) {
    el.querySelectorAll(".step[data-skill]").forEach((st) => {
      const s = byId.get(st.dataset.skill);
      const img = document.createElement("a");
      img.href = `#skills@skill-${st.dataset.skill}`;
      img.dataset.tip = st.dataset.skill;
      img.innerHTML = s ? iconImg(s) : '<span class="ph"></span>';
      st.insertBefore(img, st.firstChild);
      if (s) st.classList.add(s.type);
    });
  }

  /* ---------- Cooldown-Karten & Sequenzen ---------- */
  function cdCards(el) {
    el.querySelectorAll(".cd-card[data-skill]").forEach((c) => {
      const s = byId.get(c.dataset.skill);
      if (!s) return;
      const head = document.createElement("div");
      head.className = "head";
      head.innerHTML = `${iconImg(s)}<div><b>${esc(nameOf(s))}</b><small>${[s.cooldown ? `CD ${s.cooldown}` : "", s.mp ? `MP ${s.mp}` : ""].filter(Boolean).join(" · ")}</small></div>`;
      c.insertBefore(head, c.firstChild);
    });
  }

  /* ---------- Reiter & Routing ---------- */
  const tabButtons = [...document.querySelectorAll(".tabs button[data-tab]")];
  const panels = [...document.querySelectorAll(".tab-panel")];
  const toc = document.querySelector(".toc");

  function buildToc(panel) {
    if (!toc) return;
    const heads = [...panel.querySelectorAll("h2, h3")];
    toc.innerHTML = `<h4>Inhalt</h4>` + heads.map((h) => {
      if (!h.id) h.id = h.textContent.trim().toLowerCase().replace(/[^a-z0-9äöüß]+/g, "-").replace(/(^-|-$)/g, "");
      return `<a class="${h.tagName === "H3" ? "sub" : ""}" href="#${panel.id}@${h.id}">${esc(h.textContent)}</a>`;
    }).join("");
  }
  function activate(tabId, anchor, push) {
    const panel = panels.find((p) => p.id === tabId) || panels[0];
    if (!panel) return;
    panels.forEach((p) => p.classList.toggle("active", p === panel));
    tabButtons.forEach((b) => b.setAttribute("aria-selected", b.dataset.tab === panel.id ? "true" : "false"));
    buildToc(panel);
    if (push) history.pushState(null, "", `#${panel.id}${anchor ? "@" + anchor : ""}`);
    if (anchor) {
      const target = document.getElementById(anchor);
      if (target) {
        requestAnimationFrame(() => {
          target.scrollIntoView({ block: "start" });
          if (target.tagName === "TR") { target.classList.add("highlight"); setTimeout(() => target.classList.remove("highlight"), 2500); }
        });
      }
    } else if (push) {
      window.scrollTo({ top: 0 });
    }
  }
  function route() {
    const raw = decodeURIComponent(location.hash.slice(1));
    const [tabId, anchor] = raw.split("@");
    activate(tabId || (panels[0] && panels[0].id), anchor, false);
  }
  tabButtons.forEach((b) => b.addEventListener("click", () => activate(b.dataset.tab, null, true)));
  window.addEventListener("hashchange", route);
  document.addEventListener("click", (e) => {
    const a = e.target.closest('a[href^="#"]');
    if (!a) return;
    const raw = a.getAttribute("href").slice(1);
    if (!raw) return;
    const [tabId, anchor] = raw.split("@");
    if (panels.some((p) => p.id === tabId)) { e.preventDefault(); activate(tabId, anchor, true); }
  });

  /* ---------- Init ---------- */
  document.querySelectorAll(".skill[data-skill]").forEach(renderChip);
  document.querySelectorAll(".skill-table").forEach(skillTable);
  document.querySelectorAll(".quickbar").forEach(quickbar);
  document.querySelectorAll(".steps").forEach(steps);
  document.querySelectorAll(".cd-cards").forEach(cdCards);
  document.addEventListener("mouseover", showTip);
  document.addEventListener("mousemove", moveTip);
  document.addEventListener("mouseout", (e) => { if (e.target.closest && e.target.closest("[data-tip]")) hideTip(); });
  document.addEventListener("scroll", hideTip, { passive: true });
  route();

  // Daten-Check: alle referenzierten IDs vorhanden?
  const missing = [...document.querySelectorAll(".skill-chip.missing")].length;
  if (missing) console.warn(`[guide] ${missing} unbekannte Skill-Referenz(en)`);
  else console.info(`[guide] ${byId.size} Skills geladen, alle Referenzen aufgelöst.`);
})();
